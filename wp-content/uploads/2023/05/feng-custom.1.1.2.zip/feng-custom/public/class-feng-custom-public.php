<?php
// +----------------------------------------------------------------------
// | 晨风自定义 [ 用最简单的代码，实现最简单的事情。 ]
// +----------------------------------------------------------------------
// | Home Page: https://feng.pub/feng-custom
// +----------------------------------------------------------------------
// | Gitee: https://gitee.com/ouros/feng-custom
// +----------------------------------------------------------------------
// | WordPress: https://cn.wordpress.org/plugins/feng-custom
// +----------------------------------------------------------------------
// | Author: 阿锋 <mypen@163.com>
// +----------------------------------------------------------------------
/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://feng.pub
 *
 * @package    Feng_Custom
 * @subpackage Feng_Custom/public
 * @author     阿锋 <mypen@163.com>
 */
class Feng_Custom_Public {

	/**
	 * The ID of this plugin.
	 * 
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;
	
	/**
	 * 自定义版本号
	 * 
	 * @var string $custom_version
	 */
	private $custom_version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;
		
		// 获取自定义版本号
		$this->custom_version = maybe_unserialize(get_option('fct_custom_version'));

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Feng_Custom_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Feng_Custom_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
	    
	    if (get_option('fct_dengxiang') == '1') {
	        // 引入灯箱 Fancybox CSS
	        wp_enqueue_style( $this->plugin_name.'-fancybox', plugin_dir_url( __FILE__ ) . 'dist/fancybox/fancybox.css', array(), 'v4.0.22', 'all' );
	    }
	    
        
	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Feng_Custom_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Feng_Custom_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
	    
	    if (get_option('fct_dengxiang') == '1') {
	        // 引入灯箱 Fancybox JS
	        wp_enqueue_script( $this->plugin_name.'-fancybox', plugin_dir_url( __FILE__ ) . 'dist/fancybox/fancybox.umd.js', array( 'jquery' ), 'v4.0.22', false );
	    }
	    // 输入框七彩光子特效
	    if (get_option('fct_shurukuang') == '1') {
	        wp_enqueue_script( $this->plugin_name.'-activate-power', plugin_dir_url( __FILE__ ) . 'dist/activate-power-mode.js', array( 'jquery' ), 'v1', true );
	    }
	    
	}
	
	/**
	 * 加载自定义CSS、JS文件
	 * 
	 */
	public function enqueue_custom_file() {
	    $need_refresh = false;
	    
	    $css_version = $this->get_custom_css_version();
	    if ($css_version) {
	        $custom_css_file = WP_CONTENT_DIR . '/cache/feng-custom/static/css/custom_' . $css_version . '.css';
	        // 判断自定义css文件是否存在
	        if (!file_exists($custom_css_file)) {
	            $need_refresh = true;
	        }
	        
	    }
	    
	    $js_version = $this->get_custom_js_version();
	    if ($js_version) {
	        $custom_js_file = WP_CONTENT_DIR . '/cache/feng-custom/static/js/custom_' . $js_version . '.js';
	        // 判断自定义js文件是否存在
	        if (!file_exists($custom_js_file)) {
	            $need_refresh = true;
	        }
	        
	    }
	    
	    if ($need_refresh) {
	        $this->refresh_custom_file();
	        $css_version = $this->get_custom_css_version();
	        $js_version = $this->get_custom_js_version();
	    }
	    
	    wp_enqueue_style( $this->plugin_name, content_url() . '/cache/feng-custom/static/css/custom_'.$css_version.'.css', array(), $this->version, 'all' );
	    wp_enqueue_script( $this->plugin_name, content_url() . '/cache/feng-custom/static/js/custom_'.$js_version.'.js', array( 'jquery' ), $js_version, false );
	    
	}
	
	/**
	 * 获取自定义css版本号
	 * 
	 * @return NULL|string
	 */
	private function get_custom_css_version() {
	    $css_version = null;
	    // 判断自定义css文件是否存在
	    if (isset($this->custom_version['css_version'])) {
	        $css_version = $this->custom_version['css_version'];
	    }
	    return $css_version;
	}
	
	/**
	 * 获取自定义js版本号
	 * 
	 * @return NULL|string
	 */
	private function get_custom_js_version() {
	    $js_version = null;
	    // 判断自定义css文件是否存在
	    if (isset($this->custom_version['js_version'])) {
	        $js_version = $this->custom_version['js_version'];
	    }
	    return $js_version;
	}
	
	/**
	 * 刷新自定义CSS/JS文件
	 * 
	 */
	private function refresh_custom_file() {
	    // 重新生成自定义文件
	    require_once FENG_CUSTOM_PATH . 'includes/class-feng-custom-build.php';
	    // 有自定义文件版本，重新生成自定义文件
	    $BuildClass = new Feng_Custom_Build();
	    $BuildClass->refreshAll();
	    
	    $this->custom_version = maybe_unserialize(get_option('fct_custom_version'));
	}

}
