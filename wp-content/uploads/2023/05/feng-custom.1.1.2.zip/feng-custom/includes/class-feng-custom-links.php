<?php
// +----------------------------------------------------------------------
// | 晨风自定义 [ 用最简单的代码，实现最简单的事情。 ]
// +----------------------------------------------------------------------
// | Home Page: https://feng.pub/feng-custom
// +----------------------------------------------------------------------
// | Gitee: https://gitee.com/ouros/feng-custom
// +----------------------------------------------------------------------
// | WordPress: https://cn.wordpress.org/plugins/feng-custom
// +----------------------------------------------------------------------
// | Author: 阿锋 <mypen@163.com>
// +----------------------------------------------------------------------
/**
 * 链接类
 *
 * @author 阿锋
 *
 */
class Feng_Custom_Links {
    
    // 链接开启状态
    protected $open;
    
    // 链接配置
    protected $option;
    
    // 链接配置页面url 
    protected $adminUrl;
    
    protected $BuildClass;
    
    protected $CacheClass;
    
    // SimplePie缓存目录
    protected $simplePieCachePath;
    
    // 链接RSS聚合缓存名称
    protected $linksRssPageCacheName;
    
    // RSS聚合页面显示数量
    protected $linksRssPageLimit;
    
    // 错误信息
    protected $error;
    
    // 单例
    static public $instance;
    
    /**
     * 初始化
     */
    public function __construct() {
        $this->linksRssPageCacheName = 'links_rss_page';
        $this->linksRssPageLimit = 50;
    }
    
    /**
     * 启动链接功能
     */
    public function run() {
        $this->activate();
        add_action('init', function(){
            if (current_user_can('edit_theme_options')){
                $this->addPostStatus();
            }
            $this->pageFilter();
        });
        $this->linksRssCron();
    }
    
    /**
     * 激活链接功能
     */
    public function activate() {
        // 激活链接功能
        add_filter('pre_option_link_manager_enabled', '__return_true');
    }
    
    /**
     * 获取链接分类数据
     *
     * @param [] $param 分类参数
     *              name__like  => 链接名称
     *              include     => 包含分类ID
     *              exclude     => 排除分类ID
     *              orderby     => 排序方式
     *              order       => 排序（）
     *
     * @return []
     */
    public function getCats($param = [], $cache = false) {
        $param = wp_parse_args($param, ['taxonomy' => 'link_category']);
        $cats = get_terms( $param );
        return $cats;
    }
    
    /**
     * 获取链接列表数据
     *
     * @param [] $param 获取链接的参数
     *              category
     *              orderby rand
     *              order
     *
     */
    public function getLinks($param = []) {
        $bookmarks = get_bookmarks($param);
        return $bookmarks;
    }
    
    /**
     * 获取选择分类HTML实体
     * 
     * @param string $name 表单元素name/id
     * @param number|string|[] $category_id 被选中的分类ID
     */
    public function selectCatsDisplay($name, $category_id = 0) {
        if (!is_array($category_id)) {
            $category_id = explode(',', $category_id);
        }
        $cats = $this->getCats(['hide_empty' => 0]);
        foreach ($cats as $cat) {
           ?>
           <p>
               <label for="<?php echo $name . '_' . $cat->term_id;?>">
               		<input name="<?php echo $name;?>[]" type="checkbox" id="<?php echo $name . '_' . $cat->term_id;?>" 
               			value="<?php echo $cat->term_id; ?>" <?php echo in_array($cat->term_id, $category_id) ? 'checked' : ''; ?> />
               		<?php echo $cat->name; ?>
               </label>
           </p>
           <?php
        }
    }
    
    /**
     * 处理数据
     * @return boolean
     */
    public function doPost() {
        require_once FENG_CUSTOM_PATH . 'includes/class-feng-custom-validate.php';
        $ValidateClass = new Feng_Custom_Validate();
        $result = $ValidateClass->verify_nonce('action_nonce', 'fct-admin-option-links');
        if ($result == false) {
            $this->error = $ValidateClass->getError();
            return false;
        }
        // 开启
        $open = isset($_POST['fct_links']) ? sanitize_key($_POST['fct_links']) : 0;
        update_option('fct_links', $open);
        // 配置
        $optionData = [];
        $optionData['links_page_id'] = $ValidateClass->is_require('links_page_id', $_POST) ? (int)sanitize_key($_POST['links_page_id']) : 0;
        $optionData['links_category'] = $ValidateClass->is_require('links_category', $_POST) ? $_POST['links_category'] : '';
        $optionData['links_page_card'] = $ValidateClass->is_require('links_page_card', $_POST) ? sanitize_key($_POST['links_page_card']) : '1';
        $optionData['links_page_cats_order'] = $ValidateClass->is_require('links_page_cats_order', $_POST) ? sanitize_key($_POST['links_page_cats_order']) : '';
        $optionData['links_page_card_order'] = $ValidateClass->is_require('links_page_card_order', $_POST) ? sanitize_key($_POST['links_page_card_order']) : '';
        
        $optionData['links_rss_page_id'] = $ValidateClass->is_require('links_rss_page_id', $_POST) ? (int)sanitize_key($_POST['links_rss_page_id']) : 0;
        $optionData['links_rss_category'] = $ValidateClass->is_require('links_rss_category', $_POST) ? $_POST['links_rss_category'] : '';
        $optionData['links_rss_page_expire'] = $ValidateClass->is_require('links_rss_page_expire', $_POST) ? sanitize_key($_POST['links_rss_page_expire']) : '';
        
        $optionData['links_page_rss_cron'] = $ValidateClass->is_require('links_page_rss_cron', $_POST) ? sanitize_key($_POST['links_page_rss_cron']) : 0;
        
        $optionData['links_page_style'] = $ValidateClass->is_require('links_page_style', $_POST) ? sanitize_textarea_field($_POST['links_page_style']) : '';
        $optionData['links_page_class'] = $ValidateClass->is_require('links_page_class', $_POST) ? sanitize_textarea_field($_POST['links_page_class']) : '';
        
        $optionData['links_page_prowered'] = $ValidateClass->is_require('links_page_rss_cron', $_POST) ? sanitize_key($_POST['links_page_prowered']) : 0;
        
        // 更新配置
        update_option('fct_links_option', maybe_serialize($optionData));
        
        // 刷新文件
        $BuildClass = $this->getBuildClass();
        $BuildClass->refreshAll();
        
        // 卸载任务
        if ($optionData['links_page_rss_cron'] != 1 || $open != 1) {
            $this->linksRssCronUnset();
        }
        
        // 删除RSS聚合缓存
        $this->cleanLinksRssCache();
        
        return true;
    }
    
    /**
     * 页面管理列表添加状态
     * @param [] $states
     */
    public function addPostStatus() {
        add_filter( 'display_post_states', function($states){
            $links_option = $this->getOption();
            global $post;
            if ((int)$links_option['links_page_id'] === (int)$post->ID) {
                $states['fct_links_page'] = esc_html__('链接页面', 'feng-custom');
            }
            if ((int)$links_option['links_rss_page_id'] === (int)$post->ID) {
                $states['fct_links_rss_page'] = esc_html__('RSS聚合（链接）页面', 'feng-custom');
            }
            return $states;
        });
    }
    
    /**
     * 指定页面添加内容（友情链接、RSS聚合）
     */
    public function pageFilter() {
        $links_option = $this->getOption();
        if ($links_option['links_page_id']) {
            // 友情链接
            add_filter('the_content', function($content){
                if (!is_page()) {
                    return $content;
                }
                $links_option = $this->getOption();
                global $post;
                if ($post->ID == $links_option['links_page_id']) {
                    // 内容后添加
                    $content .= $this->linksDisplay();
                }
                return $content;
            });
        }
        if ($links_option['links_rss_page_id']) {
            // RSS聚合
            add_filter('the_content', function($content){
                if (!is_page()) {
                    return $content;
                }
                $links_option = $this->getOption();
                global $post;
                if ($post->ID == $links_option['links_rss_page_id']) {
                    // 内容后添加
                    $content .= $this->linksRssDisplay();
                }
                return $content;
            });
        }
    }
    
    /**
     * 友情链接页面内容
     * @return string
     */
    public function linksDisplay() {
        $links_option = $this->getOption();
        if (!$links_option['links_category']) {
            return sprintf(
                __('<center>请先移步至「<a href="%s">管理后台 -> 外观 -> 晨风自定义 -> 链接</a>」选择分类</center>', 'feng-custom'),
                $this->getAdminUrl()
                );
        }
        // 获取分类条件
        $cats_args = [
            'include' => $links_option['links_category'],
        ];
        // 分类排序
        $links_cats_order_type = empty($links_option['links_page_cats_order']) ? 'rand' : $links_option['links_page_cats_order'];
        if ($links_cats_order_type == 'name-asc') {
            $cats_args['orderby'] = 'name';
            $cats_args['order'] = 'ASC';
        }
        if ($links_cats_order_type == 'name-desc') {
            $cats_args['orderby'] = 'name';
            $cats_args['order'] = 'DESC';
        }
        if ($links_cats_order_type == 'id-asc') {
            $cats_args['orderby'] = 'id';
            $cats_args['order'] = 'ASC';
        }
        if ($links_cats_order_type == 'id-desc') {
            $cats_args['orderby'] = 'id';
            $cats_args['order'] = 'DESC';
        }
        // 获取分类
        $cats = $this->getCats($cats_args);
        // 链接排序
        $links_order_type = empty($links_option['links_page_card_order']) ? 'rand' : $links_option['links_page_card_order'];
        $links_args = [];
        if ($links_order_type == 'rand') {
            $links_args['orderby'] = 'rand';
        }
        if ($links_order_type == 'name-asc') {
            $links_args['orderby'] = 'name';
            $links_args['order'] = 'ASC';
        }
        if ($links_order_type == 'name-desc') {
            $links_args['orderby'] = 'name';
            $links_args['order'] = 'DESC';
        }
        if ($links_order_type == 'id-asc') {
            $links_args['orderby'] = 'id';
            $links_args['order'] = 'ASC';
        }
        if ($links_order_type == 'id-desc') {
            $links_args['orderby'] = 'id';
            $links_args['order'] = 'DESC';
        }
        if ($links_order_type == 'rating-asc') {
            $links_args['orderby'] = 'rating';
            $links_args['order'] = 'ASC';
        }
        // CSS class
        $links_css_class = empty($links_option['links_page_class']) ? '' : ' '.$links_option['links_page_class'];
        $html_content = $links_css_class ? '<div class="'. $links_option['links_page_class'] .'">' : '';
        $html_content .= '<div class="fct-links">';
        // 分类名称
        $cat_title_rand = $links_order_type == 'rand' ? __('<span>（随机排序）</span>', 'feng-custom') : '';
        foreach ($cats as $cat) {
            $html_content .= '<div class="fct-links-category">';
            $html_content .= '<div class="title">'.$cat->name. $cat_title_rand .'</div>';
            $html_content .= '</div>';
            $html_content .= '<div class="fct-links-list">';
            // 获取链接
            $links_args['category'] = $cat->term_id;
            $links = $this->getLinks($links_args);
            foreach ($links as $link) {
                $html_content .= '<div class="fct-link-card" id="link-'.$link->link_id.'">';
                $html_content .= '<div class="img"><a target="'.$link->link_target.'" href="'.$link->link_url.'"><img src="'.$link->link_image.'" /></a></div>';
                $html_content .= '<div class="info">';
                $html_content .= '  <div class="title"><a target="'.$link->link_target.'" href="'.$link->link_url.'">'.$link->link_name.'</a></div>';
                $html_content .= '  <div class="desc">'.$link->link_description.'</div>';
                $notes = $this->getLinkShowNotes($link->link_notes);
                if (!empty($notes)) {
                    $html_content .= '<div class="notes">'. $notes . '</div>';
                }
                $html_content .= '</div>';
                $html_content .= '</div>';
            }
            $html_content .= '</div>';
        }
        $html_content .= '</div>';
        $html_content .= $links_css_class ? '</div>' : '';
        
        return $html_content . $this->getProweredInfo('links');
    }
    
    /**
     * 解析前台可显示的内容
     * @param string $notes
     */
    protected function getLinkShowNotes($notes) {
        $start = strrpos($notes,"{show}");
        $end = strrpos($notes,"{/show}");
        if ($start === false || $end === false) {
            return null;
        }
        $start = $start + 6;
        $length = $end - $start;
        return substr($notes, $start, $length);
    }
    
    /**
     * RSS聚合页面内容
     * @return string
     */
    public function linksRssDisplay() {
        $links_option = $this->getOption();
        if (!$links_option['links_rss_category']) {
            return sprintf(
                __('<center>请先移步至「<a href="%s">管理后台 -> 外观 -> 晨风自定义 -> 链接</a>」选择分类</center>', 'feng-custom'),
                $this->getAdminUrl()
                );
        }
        
        // 开启RSS计划
        if ( isset($links_option['fct_links_page_rss_cron']) && $links_option['fct_links_page_rss_cron'] == 1 ) {
            return $this->getLinksRssCache();
        }else {
            $cacheExpire = $links_option['links_rss_page_expire'];
            // 未设置缓存过期时间 || 缓存过期时间大于0
            if(strlen($cacheExpire) == 0 || (strlen($cacheExpire) > 0 && (int)$cacheExpire !== 0)) {
                return $this->getLinksRssCache();
            }
        }
        return $this->getLinksRss() . $this->getProweredInfo('links-rss');
    }
    
    /**
     * 获取链接的Rss地址
     * @return array
     */
    public function getLinksRss() {
        $links_option = $this->getOption();
        // 获取链接
        $links_args = [
            'category' => $links_option['links_rss_category'],
        ];
        $links = $this->getLinks($links_args);
        // 获取Rss Url
        if (!is_array($links)) {
            return esc_html__('尚未添加链接，请前往「仪表盘->链接」添加链接。', 'feng-custom');
        }
        $rssUrl = [];
        foreach ($links as $link) {
            if ($link->link_rss) {
                $rssUrl[] = $link->link_rss;
            }
        }
        if (empty($rssUrl)) {
            return esc_html__('没有可用的RSS地址，请前往「仪表盘->链接」设置链接的RSS地址。', 'feng-custom');
        }
        $cachePath = $this->getSimplePieCachePath();
        if ($cachePath == false) {
            return esc_html__('无法创建SimplePie缓存目录，请检查目录权限。', 'feng-custom');
        }
        // 获取数量
        $limit = $links_option['links_rss_page_limit'] ? $links_option['links_rss_page_limit'] : 50;
        include_once ABSPATH . WPINC . '/class-simplepie.php';
        $SimplePie = new SimplePie();
        $SimplePie->enable_cache(true);
        $SimplePie->set_cache_location($cachePath);
        $SimplePie->set_curl_options([CURLOPT_SSL_VERIFYHOST=>false, CURLOPT_SSL_VERIFYPEER=> false]);
        $SimplePie->set_feed_url($rssUrl);
        $SimplePie->init();
        // 获取缓存类实例
        $CacheClass = $this->getCacheClass();
        // 记录信息
        $simplipielog = $CacheClass->get('links_rss_simplepie_log', 'links-log');
        $simplePieError = $SimplePie->error();
        if ($simplipielog) {
            $count = count($simplipielog) >= 5 ? 5 : count($simplipielog) + 1;
            for ($i = 0; $i < $count; $i++) {
                $simplipielog_new[$i] = $i == 0 ? ['log_time' => time(), 'feed_urls' => $rssUrl, 'error' => $simplePieError] : $simplipielog[$i - 1];
            }
            $CacheClass->update('links_rss_simplepie_log', $simplipielog_new, 'links-log');
        }else {
            $simplipielog = [
                ['log_time' => time(), 'feed_urls' => $rssUrl, 'error' => $simplePieError]
            ];
            $CacheClass->set('links_rss_simplepie_log', $simplipielog, 'links-log', 0);
        }
        // 获取RSS项目
        $rssItems = $SimplePie->get_items(0, $limit);
        // 获取Rss Url
        if (is_string($rssItems)) {
            return '<center>' . esc_html__('没有可用的RSS地址，请前往「仪表盘->链接」设置链接的RSS地址。', 'feng-custom') . '</center>';
        }
        // CSS class
        $links_css_class = empty($links_option['links_page_class']) ? '' : ' '.$links_option['links_page_class'];
        $html_content = $links_css_class ? '<div class="'. $links_option['links_page_class'] .'">' : '';
        $html_content .= '<div class="fct-links-rss">';
        // 时间格式化
        $date_format = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );
        foreach ($rssItems as $rss) {
            $feed = $rss->get_feed();
            $author = $rss->get_author();
            $publish_date = wp_date($date_format, $rss->get_date('U'));
            $html_content .= '<div class="link-rss-item">';
            $html_content .= '<div class="title"><a href="'. esc_attr($rss->get_permalink()) .'" target="_blank">'.esc_attr($rss->get_title()).'</a></div>';
            $html_content .= '<div class="meta"><span title="'.esc_attr($rss->get_date('')).'">'.$publish_date .'</span>';
            $html_content .= '<span>「<a href="'.esc_attr($feed->get_permalink()).'" target="_blank" class="">'.esc_attr($feed->get_title()).'</a>';
            if ($author) {
                $html_content .= '<i>' . sprintf(__('（作者：%s）', 'feng-custom'), esc_attr($author->name)) . '</i>';
            }
            $html_content .= '」</span></div>';
            $html_content .= '<div class="desc">'. wp_trim_words(sanitize_textarea_field($rss->get_description()), 60, '...').'</div></div>';
        }
        $html_content .= '</div>';
        $html_content .= $links_css_class ? '</div>' : '';
        $cacheExpire = $links_option['links_rss_page_expire'];
        if (strlen($cacheExpire) > 0 && (int)$cacheExpire === 0) {
            // 不缓存
            return $html_content;
        }
        // 设置缓存
        if ($links_option['links_page_rss_cron'] == 1) {
            // 混存不过期
            $cacheExpire = 0;
        }else {
            $cacheExpire = $links_option['links_rss_page_expire'] ? $links_option['links_rss_page_expire'] : 3600;
        }
        $CacheClass->set($this->linksRssPageCacheName, [
            'html_content' => $html_content,
        ], null, $cacheExpire);
        
        return $html_content;
    }
    
    /**
     * 清除links_rss_page缓存
     */
    protected function cleanLinksRssCache() {
        $CacheClass = $this->getCacheClass();
        $CacheClass->delete($this->linksRssPageCacheName);
    }
    
    /**
     * 获取links_rss_page缓存
     * @return string
     */
    protected function getLinksRssCache() {
        // 获取缓存
        $CacheClass = $this->getCacheClass();
        $cacheData = $CacheClass->get($this->linksRssPageCacheName);
        if ($cacheData) {
            return $cacheData['html_content'] . $this->getProweredInfo('links-rss');
        }else {
            return $this->getLinksRss() . $this->getProweredInfo('links-rss');
        }
    }
    
    /**
     * 定时执行RSS聚合
     */
    public function linksRssCron() {
        $links_option = $this->getOption();
        if ($links_option['links_page_rss_cron'] == 1) {
            $linksClass = Feng_Custom_Links::getInstance();
            add_action('fct_links_rss_cron_hook', array($linksClass, 'getLinksRss'));
            if(!wp_next_scheduled('fct_links_rss_cron_hook')){
                wp_schedule_event(time(), 'hourly', 'fct_links_rss_cron_hook');
            }
        }
    }
    
    /**
     * 删除定时执行RSS聚合任务
     */
    public function linksRssCronUnset() {
        $timestamp = wp_next_scheduled( 'fct_links_rss_cron_hook' );
        if ($timestamp) {
            wp_unschedule_event( $timestamp, 'fct_links_rss_cron_hook' );
        }
    }
    
    /**
     * 获取缓存目录
     * @return boolean|string
     */
    protected function getSimplePieCachePath() {
        $this->simplePieCachePath = WP_CONTENT_DIR . '/cache/feng-custom/SimplePie';
        // 判断路径是否可用
        if (is_dir($this->simplePieCachePath)) {
            return $this->simplePieCachePath;
        }
        // 递归创建目录
        if (wp_mkdir_p($this->simplePieCachePath) == true) {
            return $this->simplePieCachePath;
        }
        return false;
    }
    
    /**
     * 页面显示支持信息
     * @return string
     */
    protected function getProweredInfo($page = 'links') {
        $links_option = $this->getOption();
        if ($links_option['links_page_prowered']) {
            if ($page == 'links') {
                return '<div class="fct-prowered">Links Prowered by <a target="_blank" href="https://feng.pub/feng-custom">Feng Custom</a></div>';
            }
            if ($page == 'links-rss') {
                return '<div class="fct-prowered">RSS Prowered by <a target="_blank" href="https://feng.pub/feng-custom">Feng Custom</a></div>';
            }
        }else {
            return '';
        }
    }
    
    /**
     * 获取链接配置
     * 
     * @param boolean $refresh
     * @return []
     */
    public function getOption($refresh = false) {
        if (empty($this->option) || $refresh == true) {
            $this->option = maybe_unserialize(get_option('fct_links_option'));
        }
        return $this->option;
    }
    
    /**
     * 
     * @return string
     */
    public function getAdminUrl() {
        if (empty($this->adminUrl)) {
            $this->adminUrl = admin_url('themes.php?page=feng-custom&action=links');
        }
        return $this->adminUrl;
    }
    
    /**
     * 获取构建文件类的实例
     * @return Feng_Custom_Build
     */
    protected function getBuildClass() {
        if (empty($this->BuildClass)) {
            require_once FENG_CUSTOM_PATH . 'includes/class-feng-custom-build.php';
            $this->BuildClass = new Feng_Custom_Build();
        }
        return $this->BuildClass;
    }
    
    /**
     * 获取缓存类
     * @return Feng_Custom_Cache
     */
    protected function getCacheClass() {
        if (empty($this->CacheClass)) {
            require_once FENG_CUSTOM_PATH . 'includes/class-feng-custom-cache.php';
            $this->CacheClass = new Feng_Custom_Cache();
        }
        $this->CacheClass->setPrefix('links');
        return $this->CacheClass;
    }
    
    /**
     * 获取错误信息
     * @return string|[]
     */
    public function getError() {
        return $this->error;
    }
    
    /**
     * 单例
     * @return Feng_Custom_Links
     */
    static public function getInstance() {
        if(!self::$instance) self::$instance = new self();
        return self::$instance;
    }
}
