/**
 * 
 * 新窗口打开第三方链接，并添加小尾巴（晨风自定义）
 * 
 * 该文件不会被加载，该文件是为了方便开发使用
 * 如果您有更好的优化建议，请联系我或Gitee内提交
 * @link https://gitee.com/ouros/feng-custom
 * 
 * @author 阿锋
 * @link https://feng.pub/contact
 */

$("body").find("a").click(function(){
    var fct_lianjie_href = $(this).attr("href"), fct_lianjie_href_host = '';
    if (fct_lianjie_href != undefined) {
        var fct_lanjie_host = window.location.host;
        if (fct_lianjie_href.indexOf('#') != -1) {
            fct_lianjie_href = fct_lianjie_href.split('#');
            fct_lianjie_href_host = fct_lianjie_href[0];
            fct_lianjie_href_host = fct_lianjie_href_host.split('/');
        }else {
            fct_lianjie_href_host = fct_lianjie_href.split('/');
        }
    
        fct_lianjie_domain = fct_lianjie_href_host[2];
    
        if (fct_lianjie_domain != undefined) {
    		if (fct_lianjie_domain != fct_lanjie_host) {
    	        fct_lianjie_href = fct_change_url_par(fct_lianjie_href, fct_lianjie_par, fct_lianjie_par_value);
    	        window.open(fct_lianjie_href);
    	        return false;
        	}
    	}
    }
});

