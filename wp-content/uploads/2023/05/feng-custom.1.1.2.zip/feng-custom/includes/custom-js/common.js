/**
 * 
 * 公用方法（晨风自定义）
 * 
 * 该文件不会被加载，该文件是为了方便开发使用
 * 如果您有更好的优化建议，请联系我或Gitee内提交
 * @link https://gitee.com/ouros/feng-custom
 * 
 * @author 阿锋
 * @link https://feng.pub/contact
 */
 
/**
 * 获取随机字符串
 * @param {Object} e 获取字符串的长度
 * @param {Object} t 被选取的字符串，默认ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678
 */
function fct_get_random_string(e, t) {
  e = e || 32;
  t = t || "ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678",
  a = t.length,
  n = "";
  for (i = 0; i < e; i++) n += t.charAt(Math.floor(Math.random() * a));
  return n;
}

/**
 * 对定义的数组字符集进行随机选取
 * @@param {Object} n 数量
 * @param {Object} n  数组或半角逗号的字符串
 */
function fct_get_random_text(n, str) {
	var res = "";
	if (typeof (str) == 'string') {
		str = str.split(',');
	}
	var length = str.length;
	for (var i = 0; i < n; i++) {
		var id = Math.ceil(Math.random() * (length)) - 1;
		res += str[id];
	}
	return res;
}

// 为链接添加参数
function fct_change_url_par (destiny, par, par_value) {
    var pattern = par+'=([^&]*)';
    var replaceText = par+'='+par_value;
    if (destiny.match(pattern)) {
        var tmp = '/\\\\'+par+'=[^&]*/';
        tmp = destiny.replace(eval(tmp), replaceText);
        return (tmp);
    } else {
        if (destiny.match('[\?]')) {
            return destiny+'&'+ replaceText;
        } else {
            return destiny+'?'+replaceText;
        }
    }
    return destiny+'\\n'+par+'\\n'+par_value;
}
