<?php 
// +----------------------------------------------------------------------
// | 晨风自定义 [ 用最简单的代码，实现最简单的事情。 ]
// +----------------------------------------------------------------------
// | Home Page: https://feng.pub/feng-custom
// +----------------------------------------------------------------------
// | Gitee: https://gitee.com/ouros/feng-custom
// +----------------------------------------------------------------------
// | WordPress: https://cn.wordpress.org/plugins/feng-custom
// +----------------------------------------------------------------------
// | Author: 阿锋 <mypen@163.com>
// +----------------------------------------------------------------------
/**
 * 缓存类
 * @author 阿锋
 * 
 */
class Feng_Custom_Cache {
    
    // 缓存目录
    protected $path;
    
    // 缓存前缀
    protected $prefix;
    
    // 过期时间
    protected $expire;
    
    protected $error;
    
    function __construct() {
        // 缓存跟目录
        $this->path = WP_CONTENT_DIR . '/cache/feng-custom';
        $this->initPath();
        // 默认前缀
        $this->prefix = 'default';
        // 缓存时间，0标识不过期（秒）
        $this->expire = 0;
    }
    
    /**
     * 设置缓存数据
     * 
     * @param string $key 缓存关键字
     * @param [] data 缓存的数据
     * @param string $prefix 缓存前缀
     * @param int $expire 过期时间（秒）0表示永不过期
     */
    public function set($key, $data, $prefix = null, $expire = null) {
        $cache_data = [];
        $cache_data['key'] = $key;
        $cache_data['data'] = $data;
        // 过期时间
        $expire = $this->getExpire($expire);
        $cache_data['expire'] = $expire;
        // 前缀
        $prefix = $this->getPrefix($prefix);
        $cache_data['prefix'] = $prefix;
        if ($expire == 0) {
            // 永不过期
            $expire_time = 0;
        }else {
            // 当前时间戳
            $current_time = time();
            // 过期时间
            $expire_time = $current_time + $expire;
        }
        // 组合缓存数据
        $cache_data['expire_time'] = $expire_time;
        
        // 初始化目录
        if (!$this->initPath($prefix)) {
            return false;
        }
        // 更新缓存文件
        $this->updateCacheFile($key, $cache_data, $prefix);
    }
    
    /**
     * 更新缓存文件
     * 
     * @param string $key
     * @param string $prefix
     * @param string|[] $cache_data
     */
    private function updateCacheFile($key, $cache_data, $prefix) {
        $prefix = $this->getPrefix($prefix);
        // 缓存文件名
        $filename = $this->getCacheFilename($key, $prefix, true);
        if (is_file($filename)) {
            // 读写方式打开文件
            $file = fopen($filename, "w+");
            $filetext = fread($file, filesize($filename));
            $unserialize = maybe_unserialize($filetext);
            if (is_array($unserialize)) {
                $cache_data = array_merge($unserialize, $cache_data);
            }
        }else {
            // 写的方式打开文件
            $file = fopen($filename, "w");
        }
        // 序列化数据
        $filetext = maybe_serialize($cache_data);
        // 写入文件
        fwrite($file, $filetext);
        // 关闭文件
        fclose($file);
    }
    
    /**
     * 获取缓存数据
     * 
     * @param string $key 缓存关键字
     * @param string $prefix 缓存前缀
     * 
     * @return null|[]
     */
    public function get($key, $prefix = null) {
        $prefix = $this->getPrefix($prefix);
        $cache_data = $this->getData($key, $prefix);
        if (empty($cache_data)) {
            // 没有缓存数据
            return null;
        }
        if ($cache_data['expire_time'] == 0) {
            return $cache_data['data'];
        }
        // 当前时间
        $current_time = time();
        if ($cache_data['expire_time'] >= $current_time) {
            return $cache_data['data'];
        }
        // 删除缓存
        $this->delete($key, $prefix);
        return null;
    }
    
    /**
     * 获取缓存详细数据
     * 
     * @param string $key
     * @param string $prefix
     * @return NULL|mixed|string
     *              'key'
     *              'data'
     *              'expire'
     *              'expire_time'
     *              'prefix'
     */
    public function getData($key, $prefix = null) {
        $prefix = $this->getPrefix($prefix);
        // 获取缓存文件
        $filename = $this->getCacheFilename($key, $prefix);
        if (file_exists($filename) === false) {
            // 文件不存在
            return null;
        }
        $file = fopen($filename, "r");
        if ($file === false) {
            // 打开文件失败
            return null;
        }
        $cache_data = fread($file, filesize($filename));
        fclose($file);
        $cache_data = maybe_unserialize($cache_data);
        if (!is_array($cache_data)) {
            return null;
        }
        return $cache_data;
    }
    
    /**
     * 删除缓存
     * 
     * @param string $key 
     * @param string $prefix
     */
    public function delete($key, $prefix = null) {
        $prefix = $this->getPrefix($prefix);
        $filename = $this->getCacheFilename($key, $prefix);
        if (file_exists($filename)) {
            // 删除文件
            wp_delete_file($filename);
        }
    }
    
    /**
     * 更新缓存数据
     * 
     * @param string $key
     * @param [] $data
     * @param string $prefix
     */
    public function update($key, $data, $prefix = null) {
        $prefix = $this->getPrefix($prefix);
        $cache_data = $this->getData($key, $prefix);
        if (empty($cache_data)) {
            $this->set($key, $data, $prefix);
        }else {
            // 组合缓存数据
            $cache_data = array_merge($cache_data, ['data' => $data]);
            $this->updateCacheFile($key, $cache_data, $prefix);
        }
    }
    
    /**
     * 获取缓存文件路径名称
     * 
     * @param string $key
     * @param string $prefix
     */
    private function getCacheFilename($key, $prefix = null, $init = false) {
        $prefix = $this->getPrefix($prefix);
        if ($init) {
            $this->initPath($prefix);
        }
        $filename = $prefix . '_' . $key;
        $filename = $this->path . '/' . $prefix . '/' . md5($filename) . '.cache';
        return $filename;
    }
    
    /**
     * 设置缓存前缀
     * 
     * @param string $prefix
     */
    public function setPrefix($prefix) {
        $this->prefix = $prefix;
    }
    
    /**
     * 获取前缀
     * @param string $prefix
     */
    public function getPrefix($prefix = null) {
        return empty($prefix) ? $this->prefix : $prefix;
    }
    
    /**
     * 设置缓存过期时间，秒
     * 
     * @param string $expire
     */
    public function setExpire($expire) {
        $this->expire = $expire;
    }
    
    /**
     * 获取缓存过期时间，秒
     * @param int $expire
     */
    public function getExpire($expire = null) {
        return empty($expire) ? $this->prefix : $expire;
    }
    
    /**
     * 初始化缓存目录
     * 
     * @param string $prefix 缓存前缀
     * @return boolean
     */
    public function initPath($prefix = null) {
        $prefix = $this->getPrefix($prefix);
        // 获取缓存目录
        $path = $this->getPath($prefix);
        // 判断目录是否存在
        if (is_dir($path)) {
            return true;
        }
        // 递归创建目录
        if (wp_mkdir_p($path) != true) {
            $this->error = __('缓存目录创建失败', 'feng-custom');
            return false;
        }
        return true;
    }
    
    /**
     * 获取缓存目录
     * 
     * @param string $prefix
     * @return string
     */
    public function getPath($prefix = null) {
        $prefix = $this->getPrefix($prefix);
        return $this->path . '/' .$prefix;
    }
    
}



