<?php
// +----------------------------------------------------------------------
// | 晨风自定义 [ 用最简单的代码，实现最简单的事情。 ]
// +----------------------------------------------------------------------
// | Home Page: https://feng.pub/feng-custom
// +----------------------------------------------------------------------
// | Gitee: https://gitee.com/ouros/feng-custom
// +----------------------------------------------------------------------
// | WordPress: https://cn.wordpress.org/plugins/feng-custom
// +----------------------------------------------------------------------
// | Author: 阿锋 <mypen@163.com>
// +----------------------------------------------------------------------
/**
 * 配置类
 * 
 * @package    Feng_Custom
 * @subpackage Feng_Custom/includes
 * @author     阿锋 <mypen@163.com>
 */
class Feng_Custom_Option {
    
    // 配置
    protected $option;
    
    protected $ValidateClass;
    
    protected $BuildClass;
    
    /**
     * 错误消息
     * @var string
     */
    protected $error;
    
    public function __construct() {
        
    }
    
    /**
     * 通过POST方式更新配置
     */
    public function doPost() {
        $ValidateClass = $this->getValidateClass();
        if ($ValidateClass->verify_nonce('action_nonce', 'fct-admin-option') == false) {
            $this->error = $ValidateClass->getError();
            return false;
        }
        $data = [];
        // 过滤POST内容
        // 显示天数
        $data['fct_xianshi_tianshu'] = isset($_POST['fct_xianshi_tianshu']) ? sanitize_key($_POST['fct_xianshi_tianshu']) : '';
        $data['fct_kaitong_shijian'] = isset($_POST['fct_kaitong_shijian']) ? sanitize_textarea_field($_POST['fct_kaitong_shijian']) : '';
        $data['fct_kaitong_bangding'] = isset($_POST['fct_kaitong_bangding']) ? sanitize_textarea_field($_POST['fct_kaitong_bangding']) : '';
        $data['fct_kaitong_neirong'] = isset($_POST['fct_kaitong_neirong']) ? wp_kses_post($_POST['fct_kaitong_neirong']) : '';
        // 输入框七彩粒子特效
        $data['fct_shurukuang'] = isset($_POST['fct_shurukuang']) ? sanitize_key($_POST['fct_shurukuang']) : '';
        // 灯笼
        $data['fct_denglong'] = isset($_POST['fct_denglong']) ? sanitize_key($_POST['fct_denglong']) : '';
        $data['fct_denglong_zi_1'] = isset($_POST['fct_denglong_zi_1']) ? sanitize_textarea_field($_POST['fct_denglong_zi_1']) : '';
        $data['fct_denglong_zi_2'] = isset($_POST['fct_denglong_zi_2']) ? sanitize_textarea_field($_POST['fct_denglong_zi_2']) : '';
        $data['fct_denglong_kaishi'] = isset($_POST['fct_denglong_kaishi']) ? sanitize_textarea_field($_POST['fct_denglong_kaishi']) : '';
        $data['fct_denglong_jieshu'] = isset($_POST['fct_denglong_jieshu']) ? sanitize_textarea_field($_POST['fct_denglong_jieshu']) : '';
        // 网页灰色
        $data['fct_huise'] = isset($_POST['fct_huise']) ? sanitize_key($_POST['fct_huise']) : '';
        $data['fct_huise_kaishi'] = isset($_POST['fct_huise_kaishi']) ? sanitize_textarea_field($_POST['fct_huise_kaishi']) : '';
        $data['fct_huise_jieshu'] = isset($_POST['fct_huise_jieshu']) ? sanitize_textarea_field($_POST['fct_huise_jieshu']) : '';
        // 灯箱
        $data['fct_dengxiang'] = isset($_POST['fct_dengxiang']) ? sanitize_key($_POST['fct_dengxiang']) : '';
        $data['fct_dengxiang_bangding'] = isset($_POST['fct_dengxiang_bangding']) ? sanitize_textarea_field($_POST['fct_dengxiang_bangding']) : '';
        // 链接小尾巴
        $data['fct_lianjie'] = isset($_POST['fct_lianjie']) ? sanitize_key($_POST['fct_lianjie']) : '';
        $data['fct_lianjie_weiba'] = isset($_POST['fct_lianjie_weiba']) ? sanitize_textarea_field($_POST['fct_lianjie_weiba']) : '';
        
        // 验证数据
        $data = $this->validate($data);
        if ($data === false) {
            return false;
        }
        
        // 更新配置项
        $this->updateOption($data);
        
        // 更新文件
        return $this->buildJsCss();
    }
    
    /**
     * 批量验证数据
     * @param array $data 
     * @return false|array 字符串表示验证失败
     */
    protected function validate($data) {
        $ValidateClass = $this->getValidateClass();

            // 验证通过后重构数据
        $success = [];

        /**
         * 输入框七彩光子特效
         */
        $data['fct_shurukuang'] = isset($data['fct_shurukuang']) ? $data['fct_shurukuang'] : 0;
        $success['fct_shurukuang'] = $data['fct_shurukuang'] == 1 ? '1' : '0';

        /**
         * 运行天数
         */
        $data['fct_xianshi_tianshu'] = isset($data['fct_xianshi_tianshu']) ? $data['fct_xianshi_tianshu'] : 0;
        $success['fct_xianshi_tianshu'] = $data['fct_xianshi_tianshu'] == 1 ? '1' : '0';
        if ($data['fct_xianshi_tianshu'] == '1') {
            // 开通时间
            if (! $data['fct_kaitong_shijian']) {
                $this->error = esc_html__('显示运行天数，开通时间 不能为空！', 'feng-custom');
                return false;
            }
            // 绑定元素
            if (!$data['fct_kaitong_bangding']) {
                $this->error = esc_html__('显示运行天数，绑定元素 不能为空！', 'feng-custom');
                return false;
            }
            // 显示内容
            if (!$data['fct_kaitong_neirong']) {
                $this->error = esc_html__('显示运行天数，显示内容 不能为空！', 'feng-custom');
                return false;
            }
        }
        // 开通时间
        $timeline = '';
        if ($ValidateClass->is($data['fct_kaitong_shijian'], 'require')) {
            $timeline = $ValidateClass->is_date($data['fct_kaitong_shijian'], true);
            if ($timeline === false) {
                $this->error = esc_html__('博客开通时间格式错误！', 'feng-custom');
                return false;
            }
        }
        $success['fct_kaitong_shijian'] = $timeline;
        
        // 绑定元素
        $success['fct_kaitong_bangding'] = wp_filter_post_kses($data['fct_kaitong_bangding']);
        // 显示内容
        $success['fct_kaitong_neirong'] = wp_filter_post_kses($data['fct_kaitong_neirong']);
        
        /**
         * 灯笼
         */
        $data['fct_denglong'] = isset($data['fct_denglong']) ? $data['fct_denglong'] : 0;
        $success['fct_denglong'] = $data['fct_denglong'] == 1 ? '1' : '0';
        // 灯笼文字
        if ($data['fct_denglong'] == '1') {
            if ($ValidateClass->is($data['fct_denglong_zi_1'], 'require') == false) {
                $this->error = esc_html__('前一个灯笼文字不能为空！', 'feng-custom');
                return false;
            }
            if ($ValidateClass->is($data['fct_denglong_zi_2'], 'require') == false) {
                $this->error = esc_html__('后一个灯笼第文字不能为空！', 'feng-custom');
                return false;
            }
        }
        $success['fct_denglong_zi_1'] = sanitize_text_field($data['fct_denglong_zi_1']);
        $success['fct_denglong_zi_2'] = sanitize_text_field($data['fct_denglong_zi_2']);
        // 开始时间
        $timeline = '';
        if ($ValidateClass->is($data['fct_denglong_kaishi'], 'require')) {
            $timeline = $ValidateClass->is_date($data['fct_denglong_kaishi'], true);
            if ($timeline === false) {
                $this->error = esc_html__('灯笼点亮开始时间格式错误！', 'feng-custom');
                return false;
            }
        }
        $success['fct_denglong_kaishi'] = $timeline;
        
        // 结束时间
        $timeline = '';
        if ($ValidateClass->is($data['fct_denglong_jieshu'], 'require')) {
            $timeline = $ValidateClass->is_date($data['fct_denglong_jieshu'], true);
            if ($timeline === false) {
                $this->error = esc_html__('灯笼点亮开始时间格式错误！', 'feng-custom');
                return false;
            }
        }
        $success['fct_denglong_jieshu'] = $timeline;
        
        /**
         * 网页灰色
         */
        $data['fct_huise'] = isset($data['fct_huise']) ? $data['fct_huise'] : 0;
        $success['fct_huise'] = $data['fct_huise'] == 1 ? '1' : '0';
        // 开始时间
        $timeline = '';
        if ($ValidateClass->is($data['fct_huise_kaishi'], 'require')) {
            $timeline = $ValidateClass->is_date($data['fct_huise_kaishi'], true);
            if ($timeline === false) {
                $this->error = esc_html__('灯笼点亮开始时间格式错误！', 'feng-custom');
                return false;
            }
        }
        $success['fct_huise_kaishi'] = $timeline;
        
        // 结束时间
        $timeline = '';
        if ($ValidateClass->is($data['fct_huise_jieshu'], 'require')) {
            $timeline = $ValidateClass->is_date($data['fct_huise_jieshu'], true);
            if ($timeline === false) {
                $this->error = esc_html__('灯笼点亮开始时间格式错误！', 'feng-custom');
                return false;
            }
        }
        $success['fct_huise_jieshu'] = $timeline;
        
        /**
         * 灯箱
         */
        $data['fct_dengxiang'] = isset($data['fct_dengxiang']) ? $data['fct_dengxiang'] : 0;
        $success['fct_dengxiang'] = $data['fct_dengxiang'] == 1 ? '1' : '0';
        if ($data['fct_dengxiang'] == '1') {
            if ($ValidateClass->is($data['fct_dengxiang_bangding'], 'require') == false) {
                $this->error = esc_html__('灯箱绑定图片元素不能为空！', 'feng-custom');
                return false;
            }
        }
        $success['fct_dengxiang_bangding'] = wp_filter_post_kses($data['fct_dengxiang_bangding']);
        
        /**
         * 第三方链接小尾巴
         */
        $data['fct_lianjie'] = isset($data['fct_lianjie']) ? $data['fct_lianjie'] : 0;
        $success['fct_lianjie'] = $data['fct_lianjie'] == 1 ? '1' : '0';
        if ($data['fct_lianjie'] == '1') {
            if ($ValidateClass->is($data['fct_lianjie_weiba'], 'require') == false) {
                $this->error = esc_html__('链接小尾巴不能为空！', 'feng-custom');
                return false;
            }
        }
        $success['fct_lianjie_weiba'] = wp_filter_post_kses($data['fct_lianjie_weiba']);
        
        // Success
        return $success;
    }
    
    /**
     * 批量更新配置项目
     *
     * @param array $data
     * @return boolean
     */
    protected function updateOption($data) {
        foreach ($data as $f => $v) {
            // 如果为数组，需要序列化
            $v = is_array($v) ? maybe_serialize($v) : $v;
            update_option($f, $v);
        }
    }
    
    /**
     * 获取配置
     * @param boolean $refresh 刷新配置
     */
    public function getOption($refresh = false) {
        if (empty($this->option) || $refresh == true) {
            $this->option = [
                // 显示天数
                'fct_xianshi_tianshu' => get_option('fct_xianshi_tianshu'),
                'fct_kaitong_shijian' => get_option('fct_kaitong_shijian'),
                'fct_kaitong_bangding' => get_option('fct_kaitong_bangding'),
                'fct_kaitong_neirong' => get_option('fct_kaitong_neirong'),
                // 七彩粒子输入框
                'fct_shurukuang' => get_option('fct_shurukuang'),
                // 灯笼
                'fct_denglong' => get_option('fct_denglong'),
                'fct_denglong_zi_1' => get_option('fct_denglong_zi_1'),
                'fct_denglong_zi_2' => get_option('fct_denglong_zi_2'),
                'fct_denglong_kaishi' => get_option('fct_denglong_kaishi'),
                'fct_denglong_jieshu' => get_option('fct_denglong_jieshu'),
                // 博客灰色
                'fct_huise' => get_option('fct_huise'),
                'fct_huise_kaishi' => get_option('fct_huise_kaishi'),
                'fct_huise_jieshu' => get_option('fct_huise_jieshu'),
                // 图片灯箱
                'fct_dengxiang' => get_option('fct_dengxiang'),
                'fct_dengxiang_bangding' => get_option('fct_dengxiang_bangding'),
                // 链接小尾巴
                'fct_lianjie' => get_option('fct_lianjie'),
                'fct_lianjie_weiba' => get_option('fct_lianjie_weiba'),
            ];
        }
        return $this->option;
    }
        
    /**
     * 处理雪花特效配置
     * 
     * @return boolean
     */
    public function doPostSnowflake() {
        $ValidateClass = $this->getValidateClass();
        if ($ValidateClass->verify_nonce('action_nonce', 'fct-admin-option-snowflake') == false) {
            $this->error = $ValidateClass->getError();
            return false;
        }
        // 雪花特效
        $data['fct_xuehua'] = isset($_POST['fct_xuehua']) ? sanitize_key($_POST['fct_xuehua']) : '';
        $data['fct_xuehua_option'] = isset($_POST['fct_xuehua_option']) ? $_POST['fct_xuehua_option'] : [];
        
        // 验证数据
        $data = $this->validateSnowflake($data);
        if ($data === false) {
            return false;
        }
        
        // 更新配置项
        update_option('fct_xuehua', $data['fct_xuehua']);
        update_option('fct_xuehua_option', maybe_serialize($data['fct_xuehua_option']));
        
        // 更新自定义文件
        return $this->buildJsCss();
    }
    
    /**
     * 雪花特效验证数据
     * @param [] $data
     * @return boolean
     */
    protected function validateSnowflake($data) {
        $ValidateClass = $this->getValidateClass();
        /**
         * 雪花特效
         */
        $data['fct_xuehua'] = isset($data['fct_xuehua']) ? $data['fct_xuehua'] : 0;
        $success['fct_xuehua'] = $data['fct_xuehua'] == 1 ? '1' : '0';
        // 飘落图片
        $data['fct_xuehua_option']['image'] = wp_filter_post_kses($data['fct_xuehua_option']['image']);
        // 雪花字符
        if ($ValidateClass->is('text', 'require', $data['fct_xuehua_option'])) {
            $success['fct_xuehua_option']['text'] = sanitize_text_field($data['fct_xuehua_option']['text']);
        }else {
            $success['fct_xuehua_option']['text'] = '';
        }
        // 雪花颜色
        if ($ValidateClass->is('color', 'require', $data['fct_xuehua_option'])) {
            $success['fct_xuehua_option']['color'] = sanitize_text_field($data['fct_xuehua_option']['color']);
        }else {
            $success['fct_xuehua_option']['color'] = '';
        }
        // 雪花大小
        $min = '';
        $max = '';
        if ($ValidateClass->is('minSize', 'number', $data['fct_xuehua_option'])) {
            if ($ValidateClass->is_egt(0, 'minSize', $data['fct_xuehua_option'])) {
                $this->error = esc_html__('雪花大小：最小雪花参数应大于零', 'feng-custom');
                return false;
            }
            $min = sanitize_text_field($data['fct_xuehua_option']['minSize']);
        }
        if ($ValidateClass->is('maxSize', 'number', $data['fct_xuehua_option'])) {
            if ($ValidateClass->is_egt(0, 'maxSize', $data['fct_xuehua_option'])) {
                $this->error = esc_html__('雪花大小：最大雪花参数应大于零', 'feng-custom');
                return false;
            }
            $max = sanitize_text_field($data['fct_xuehua_option']['maxSize']);
        }
        if ($min && $max) {
            if (!$ValidateClass->is_lt($min, $max)) {
                $this->error = esc_html__('雪花大小：设置的范围有误', 'feng-custom');
                return false;
            }
        }else {
            if (!(empty($min) && empty($max))) {
                $this->error = esc_html__('雪花大小：请完善参数', 'feng-custom');
                return false;
            }
        }
        $success['fct_xuehua_option']['minSize'] = $min;
        $success['fct_xuehua_option']['maxSize'] = $max;
        // 飘落时间
        $min = '';
        $max = '';
        if ($ValidateClass->is('minSpeed', 'number', $data['fct_xuehua_option'])) {
            if ($ValidateClass->is_egt(0, 'minSpeed', $data['fct_xuehua_option'])) {
                $this->error = esc_html__('雪花飘落速度：最小速度应大于零', 'feng-custom');
                return false;
            }
            $min = sanitize_text_field($data['fct_xuehua_option']['minSpeed']);
        }
        if ($ValidateClass->is('maxSpeed', 'number', $data['fct_xuehua_option'])) {
            if ($ValidateClass->is_egt(0, 'maxSpeed', $data['fct_xuehua_option'])) {
                $this->error = esc_html__('雪花飘落速度：最大速度应大于零', 'feng-custom');
                return false;
            }
            $max = sanitize_text_field($data['fct_xuehua_option']['maxSpeed']);
        }
        if ($min && $max) {
            if (!$ValidateClass->is_lt($min, $max)) {
                $this->error = esc_html__('雪花飘落速度：最小速度不能大于或等于最大速度', 'feng-custom');
                return false;
            }
        }else {
            if (!(empty($min) && empty($max))) {
                $this->error = esc_html__('雪花飘落速度：请完善雪花飘落速度的设置', 'feng-custom');
                return false;
            }
        }
        $success['fct_xuehua_option']['minSpeed'] = $min;
        $success['fct_xuehua_option']['maxSpeed'] = $max;
        // 雪花飘落数量
        if ($ValidateClass->is('count', 'number', $data['fct_xuehua_option'])) {
            if ($ValidateClass->is_lt(1000, 'count', $data['fct_xuehua_option'])) {
                $this->error = esc_html__('飘落的雪花总数不能大于1000', 'feng-custom');
                return false;
            }
            $success['fct_xuehua_option']['count'] = sanitize_text_field($data['fct_xuehua_option']['count']);
        }else {
            $success['fct_xuehua_option']['count'] = '';
        }
        // 雪花图层等级
        if ($ValidateClass->is('zIndex', 'number', $data['fct_xuehua_option'])) {
            $success['fct_xuehua_option']['zIndex'] = sanitize_text_field($data['fct_xuehua_option']['zIndex']);
        }else {
            $success['fct_xuehua_option']['zIndex'] = '';
        }
        $success['fct_xuehua_option'] = $data['fct_xuehua_option'];
        return $success;
    }
    
    /**
     * 获取雪花飘落配置
     * 
     * @param boolean $refresh
     * @return []
     */
    public function getOptionSnowflake($refresh = false) {
        if (empty($this->option['snowflake']) || $refresh == true) {
            $this->option['snowflake'] = maybe_unserialize(get_option('fct_xuehua_option'));
        }
        return $this->option['snowflake'];
    }
    
    /**
     * 获取验证器实例
     * @return Feng_Custom_Validate
     */
    private function getValidateClass() {
        if (empty($this->ValidateClass)) {
            require_once FENG_CUSTOM_PATH . 'includes/class-feng-custom-validate.php';
            $this->ValidateClass = new Feng_Custom_Validate();
        }
        return $this->ValidateClass;
    }
    
    /**
     * 获取建立自定义文件类实例
     * @return 
     */
    private function getBuildClass() {
        if (empty($this->BuildClass)) {
            require_once FENG_CUSTOM_PATH . 'includes/class-feng-custom-build.php';
            $this->BuildClass = new Feng_Custom_Build();
        }
        return $this->BuildClass;
    }
    
    /**
     * 更新JS、CSS文件
     * @return boolean
     */
    private function buildJsCss() {
        $BuildClass = $this->getBuildClass();
        if ($BuildClass->refreshAll() == false) {
            $this->error = $BuildClass->getError();
            return false;
        }
        return true;
    }
    
    /**
     * 返回错误信息
     * @return string
     */
    public function getError() {
        return $this->error;
    }
    
}