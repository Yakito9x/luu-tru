<?php
// +----------------------------------------------------------------------
// | 晨风自定义 [ 用最简单的代码，实现最简单的事情。 ]
// +----------------------------------------------------------------------
// | Home Page: https://feng.pub/feng-custom
// +----------------------------------------------------------------------
// | Gitee: https://gitee.com/ouros/feng-custom
// +----------------------------------------------------------------------
// | WordPress: https://cn.wordpress.org/plugins/feng-custom
// +----------------------------------------------------------------------
// | Author: 阿锋 <mypen@163.com>
// +----------------------------------------------------------------------
/**
 * Fired during plugin deactivation
 *
 * @link       http://feng.pub
 *
 * @package    Feng_Custom
 * @subpackage Feng_Custom/includes
 * @author     阿锋 <mypen@163.com>
 */
class Feng_Custom_Deactivator {

	/**
	 * 禁用插件时执行
	 */
	public static function deactivate() {
	    // 关闭所有配置开关
	    update_option('fct_xianshi_tianshu', '0');
	    update_option('fct_shurukuang', '0');
	    update_option('fct_denglong', '0');
	    update_option('fct_huise', '0');
	    update_option('fct_dengxiang', '0');
	    update_option('fct_lianjie', '0');
	    update_option('fct_xuehua', '0');
	    update_option('fct_links', '0');
	}

}
