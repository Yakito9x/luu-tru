<?php
// +----------------------------------------------------------------------
// | 晨风自定义 [ 用最简单的代码，实现最简单的事情。 ]
// +----------------------------------------------------------------------
// | Home Page: https://feng.pub/feng-custom
// +----------------------------------------------------------------------
// | Gitee: https://gitee.com/ouros/feng-custom
// +----------------------------------------------------------------------
// | WordPress: https://cn.wordpress.org/plugins/feng-custom
// +----------------------------------------------------------------------
// | Author: 阿锋 <mypen@163.com>
// +----------------------------------------------------------------------
/**
 * 验证类 
 * 
 * @package    Feng_Custom
 * @subpackage Feng_Custom/includes
 * @author     阿锋 <mypen@163.com>
 */
Class Feng_Custom_Validate {
    
    /**
     * 错误信息
     * @var string|[]
     */
    protected $error;
    
    /**
     * 验证表单随机数（POST数据）
     * 
     * @param string $name 表单元素名
     * @param string $nonce Nonce
     * @return boolean
     */
    public function verify_nonce($name, $nonce) {
        if (!isset($_POST[$name])) {
            $this->error = esc_html__('缺少参数！', 'feng-custom');
            return false;
        }
        // 验证随机数
        $result = wp_verify_nonce($_POST[$name], $nonce);
        if ($result !== 1) {
            $this->error = esc_html__('数据出错，请重新提交！', 'feng-custom');
            return false;
        }
        return true;
    }
    
    /**
     * 判断是否为时间格式
     * @param string $value 格式化的时间
     * @param boolean $timestamp 是否返回时间戳
     * @return boolean
     */
    public function is_date($value, $timestamp = false) {
        if ($this->is($value, 'require') == false) {
            return false;
        }
        $time = strtotime($value);
        if ($time && $timestamp == true) {
            return $time;
        }else if ($time) {
            return true;
        }else {
            return false;
        }
    }
    
    /**
     * 验证字段值是否为有效格式
     * @access public
     * @param mixed  $value 字段值｜字段
     * @param string $rule  验证规则
     * @param array  $data  数据
     * @return bool
     */
    public function is($value, string $rule, array $data = []): bool
    {
        if (!empty($data)) {
            $value = $this->getDataValue($data, $value);
        }
        switch ($rule) {
            case 'require':
                // 必须不能为空
                $result = !empty($value) || '0' == $value;
                break;
            case 'accepted':
                // 接受
                $result = in_array($value, ['1', 'on', 'yes']);
                break;
            case 'date':
                // 是否是一个有效日期
                $result = false !== strtotime($value);
                break;
            case 'activeUrl':
                // 是否为有效的网址
                $result = checkdnsrr($value);
                break;
            case 'boolean':
            case 'bool':
                // 是否为布尔值
                $result = in_array($value, [true, false, 0, 1, '0', '1'], true);
                break;
            case 'number':
                // 验证某个字段的值是否为纯数字（采用ctype_digit验证，不包含负数和小数点）
                $result = ctype_digit((string) $value);
                break;
            case 'alphaNum':
                $result = ctype_alnum($value);
                break;
            case 'array':
                // 是否为数组
                $result = is_array($value);
                break;
            default:
                $result = false;
                break;
        }
        return $result;
    }
    
    /**
     * 字段必须（可以为空）
     * 
     * @param string $name 字段名称
     * @param [] $data 数据
     */
    public function is_require($name, $data) {
        return isset($data[$name]) ? true : false;
    }
    
    /**
     * 验证是否大于等于某个值 >=
     * @access public
     * @param mixed $value 字段值
     * @param mixed $rule  验证规则｜字段
     * @param array $data  数据
     * @return bool
     */
    public function is_egt($value, $rule, array $data = []): bool
    {
        return $value >= $this->getDataValue($data, $rule);
    }
    
    /**
     * 验证是否大于某个值 >
     * @access public
     * @param mixed $value 字段值
     * @param mixed $rule  验证规则｜字段
     * @param array $data  数据
     * @return bool
     */
    public function is_gt($value, $rule, array $data = []): bool
    {
        return $value > $this->getDataValue($data, $rule);
    }
    
    /**
     * 验证是否小于等于某个值 <=
     * @access public
     * @param mixed $value 字段值
     * @param mixed $rule  验证规则｜字段
     * @param array $data  数据
     * @return bool
     */
    public function is_elt($value, $rule, array $data = []): bool
    {
        return $value <= $this->getDataValue($data, $rule);
    }
    
    /**
     * 验证是否小于某个值 <
     * @access public
     * @param mixed $value 字段值
     * @param mixed $rule  验证规则｜字段
     * @param array $data  数据
     * @return bool
     */
    public function is_lt($value, $rule, array $data = []): bool
    {
        return $value < $this->getDataValue($data, $rule);
    }
    
    /**
     * 验证是否等于某个值 =
     * @access public
     * @param mixed $value 字段值
     * @param mixed $rule  验证规则｜字段
     * @return bool
     */
    public function is_eq($value, $rule): bool
    {
        return $value == $rule;
    }
    
    /**
     * 获取数据值
     * @access protected
     * @param array  $data 数据
     * @param string $key  数据标识 支持二维
     * @return mixed
     */
    protected function getDataValue(array $data, $key)
    {
        if (is_numeric($key)) {
            $value = $key;
        } elseif (is_string($key) && strpos($key, '.')) {
            // 支持多维数组验证
            foreach (explode('.', $key) as $key) {
                if (!isset($data[$key])) {
                    $value = null;
                    break;
                }
                $value = $data = $data[$key];
            }
        } else {
            $value = $data[$key] ?? null;
        }
        
        return $value;
    }
    
    /**
     * 获取错误信息
     * @return string|[]
     */
    public function getError() {
        return $this->error;
    }
}