<?php
// +----------------------------------------------------------------------
// | 晨风自定义 [ 用最简单的代码，实现最简单的事情。 ]
// +----------------------------------------------------------------------
// | Home Page: https://feng.pub/feng-custom
// +----------------------------------------------------------------------
// | Gitee: https://gitee.com/ouros/feng-custom
// +----------------------------------------------------------------------
// | WordPress: https://cn.wordpress.org/plugins/feng-custom
// +----------------------------------------------------------------------
// | Author: 阿锋 <mypen@163.com>
// +----------------------------------------------------------------------
/**
 * 构建自定义文件（js、css）
 * 
 * @author 阿锋
 *
 */
class Feng_Custom_Build {
    
    // 静态文件路径
    protected $static_path;
    
    // 自定义CSS文件的版本
    protected $custom_css_version;
    
    // 新文件版本号
    protected $custom_css_new_version;
    
    // 自定义JS文件的版本
    protected $custom_js_version;
    
    // 新文件版本号
    protected $custom_js_new_version;
    
    // CSS内容
    protected $style_line;
    
    // 当前自定义CSS文件名
    protected $custom_css_filename;
    
    // JS内容
    protected $script_line;
    
    // 当前自定义JS文件名
    protected $custom_js_filename;
    
    // 错误信息
    protected $error;
    
    public function __construct() {
        $this->static_path = WP_CONTENT_DIR . '/cache/feng-custom/static';
        $this->initPath();
        $custom_version = maybe_unserialize(get_option('fct_custom_version'));
        $this->custom_css_version = isset($custom_version['css_version']) ? $custom_version['css_version'] : null;
        $this->custom_js_version = isset($custom_version['js_version']) ? $custom_version['js_version'] : null;
    }
    
    /**
     * 刷新自定义CSS文件
     * 
     */
    public function refreshCss() {
        // 欢庆佳节 
        if (get_option('fct_denglong') == '1') {
            $this->appendStyle('denglong.min.css', 'filename');
        }
        
        // 友情链接
        if (get_option('fct_links') == '1') {
            $this->appendStyle('links.min.css', 'filename');
            $links_option = maybe_unserialize(get_option('fct_links_option'));
            $links_css = $links_option['links_page_card'] ? 'links-'.$links_option['links_page_card'].'.min.css' : 'links-1.min.css';
            $this->appendStyle($links_css, 'filename');
            $this->appendStyle($links_option['links_page_style'], 'string');
        }
        
        $result = $this->customCssFile();
        if ($result) {
            // 刷新CSS版本
            $this->refreshVersion('CSS');
        }
        return $result;
    }
    
    /**
     * 刷新自定义JS文件
     * 
     */
    public function refreshJs() {
        // 运行天数
        if (get_option('fct_xianshi_tianshu') == '1') {
            $blogStartDate = fct_get_date(get_option('fct_kaitong_shijian'));
            $bindElement = get_option('fct_kaitong_bangding');
            $blogDaysHtml = get_option('fct_kaitong_neirong');
            // 判断是否满足条件
            if ($blogStartDate && $bindElement && $blogDaysHtml) {
                // 替换天数
                $blogDaysHtml = str_replace('{days}', '\'+ fct_run_days +\'', $blogDaysHtml);
                $script = 'var fct_blog_start = "'.$blogStartDate.'"; var fct_build_date = new Date(fct_blog_start), fct_now_date = new Date(); var fct_tianshu_T = (fct_now_date.getTime() - fct_build_date.getTime()), fct_tianshu_M = 24 * 60 * 60 * 1000; var fct_run_days = Math.floor(fct_tianshu_T/fct_tianshu_M); $(\''.$bindElement.'\').append(\''.$blogDaysHtml.'\'); ';
                $this->appendScript($script, 'string');
            }
        }
        
        // 输入框七彩光子特效
        if (get_option('fct_shurukuang') == '1') {
            $script = 'POWERMODE.colorful = true; POWERMODE.shake = false; document.body.addEventListener(\'input\', POWERMODE); ';
            $this->appendScript($script, 'string');
        }
        
        // 欢庆佳节 
        if (get_option('fct_denglong') == '1') {
            $startTime = get_option('fct_denglong_kaishi');
            $endTime = get_option('fct_denglong_jieshu');
            $deng_zi_1 = get_option('fct_denglong_zi_1');
            $deng_zi_2 = get_option('fct_denglong_zi_2');
            $script = $this->getStartEndTime('deng', $startTime, $endTime);
            $script .= 'var fct_deng_first_text = "'.$deng_zi_1.'", fct_deng_second_text = "'.$deng_zi_2.'"; if (fct_deng_show == 1) { $(\'body\').append(\'<div class="deng-box1"><div class="deng"><div class="xian"></div><div class="deng-a"><div class="deng-b"><div class="deng-t">\'+ fct_deng_second_text +\'</div></div></div><div class="shui shui-a"><div class="shui-c"></div><div class="shui-b"></div></div></div></div><div class="deng-box2"><div class="deng"><div class="xian"></div><div class="deng-a"><div class="deng-b"><div class="deng-t">\'+ fct_deng_first_text +\'</div></div></div><div class="shui shui-a"><div class="shui-c"></div><div class="shui-b"></div></div></div></div>\'); } ';
            $this->appendScript($script, 'string');
        }
        
        // 博客灰色
        if (get_option('fct_huise') == '1') {
            $startTime = get_option('fct_huise_kaishi');
            $endTime = get_option('fct_huise_jieshu');
            $script = $this->getStartEndTime('huise', $startTime, $endTime);
            $script .= 'if (fct_huise_show == 1) { $(\'html\').css({\'filter\':\'grayscale(100%)\', \'-webkit-filter\':\'grayscale(100%)\', \'-moz-filter\':\'grayscale(100%)\', \'-ms-filter\':\'grayscale(100%)\', \'-o-filter\':\'grayscale(100%)\', \'filter\':\'progid:DXImageTransform.Microsoft.BasicImage(grayscale=1)\', \'-webkit-filter\':\'grayscale(1)\', });}';
            $this->appendScript($script, 'string');
        }
        
        // 灯箱
        if (get_option('fct_dengxiang') == '1') {
            $bindElement = get_option('fct_dengxiang_bangding');
            $script = 'Fancybox.bind(\''.$bindElement.'\', { groupAll : true }); ';
            $this->appendScript($script, 'string');
        }
        
        // 链接小尾巴
        if (get_option('fct_lianjie') == '1') {
            $weiba = get_option('fct_lianjie_weiba');
            if ($weiba) {
                $weiba = explode('=', $weiba);
            }
            $script = 'var fct_lianjie_par = "'. $weiba[0]. '", fct_lianjie_par_value = "'. $weiba[1] . '";';
            $this->appendScript($script, 'string');
            $this->appendScript('lianjie.min.js', 'filename');
        }
        
        // 雪花特效
        if (get_option('fct_xuehua') == '1') {
            $this->buildXuehuaJs();
        }
        
        $result = $this->customJsFile();
        if ($result) {
            $this->refreshVersion('JS');
        }
        return $result;
    }
    
    /**
     * 获取时间判断代码
     * @param string $name 标识
     * @param int $start 时间戳
     * @param int $end 时间戳
     */
    private function getStartEndTime($name, $start, $end) {
        if($start && $end) {
            $start .= '000';
            $end .= '000';
            $script = 'var fct_'.$name.'_show = 0, fct_'.$name.'_start_time = '.$start.', fct_'.$name.'_end_time = '.$end.', fct_'.$name.'_time_now = Date.now();if (fct_'.$name.'_time_now >= fct_'.$name.'_start_time && fct_'.$name.'_time_now < fct_'.$name.'_end_time) {    fct_'.$name.'_show = 1;}';
        }elseif($start) {
            $start .= '000';
            $script = 'var fct_'.$name.'_show = 0, fct_'.$name.'_start_time = '.$start.', fct_'.$name.'_time_now = Date.now(); if (fct_'.$name.'_time_now >= fct_'.$name.'_start_time) { fct_'.$name.'_show = 1; }';
        }elseif($end) {
            $end .= '000';
            $script = 'var fct_'.$name.'_show = 0, fct_'.$name.'_end_time = '.$end.', fct_'.$name.'_time_now = Date.now(); if (fct_'.$name.'_time_now < fct_'.$name.'_end_time) { fct_'.$name.'_show = 1; }';
        }else {
            $script = 'var fct_'.$name.'_show = 1;';
        }
        return $script;
    }
    
    /**
     * 构建雪花特效
     */
    private function buildXuehuaJs(){
        $xuehua_option = maybe_unserialize(get_option('fct_xuehua_option'));
        $forcount = count($xuehua_option);
        $script = 'var fct_xuehua_option={';
        foreach ($xuehua_option as $key => $value) {
            $i = 0;
            if ($value) {
                if ($key == 'image') {
                    // 转换为数组，过滤半角逗号方便js前端使用
                    $image = explode("\r\n", str_replace(",", "", $value));
                    $allow = ['png', 'jpg', 'jpeg', 'gif', 'webp'];
                    foreach ($image as $k => $v) {
                        if (filter_var($v, FILTER_VALIDATE_URL)) {
                            $image[$k] = $v;
                        }else {
                            $ext = substr($v,(strrpos($v,'.')+1));
                            if (in_array($ext, $allow)) {
                                $image[$k] = FENG_CUSTOM_URL . 'public/img/' . $v;
                            }else {
                                unset($image[$k]);
                            }
                        }
                    }
                    $value = implode(',', $image);
                }
                if ($i < $forcount) {
                    $script .= $key.': "'. $value .'", ';
                }else {
                    $script .= $key.': "'. $value .'" ';
                }
            }
            $i++;
        }
        $script .= '};';
        // 配置传入js
        $this->appendScript($script, 'string');
        $this->appendScript('xuehua.min.js', 'filename');
    }
    
    /**
     * 刷新CSS、JS文件
     * @return boolean
     */
    public function refreshAll() {
        $resultCss = $this->refreshCss();
        $resultJs = $this->refreshJs();
        if ($resultCss == false || $resultJs == false) {
            return false;
        }
        $this->refreshVersion();
        return true;
    }
    
    /**
     * 更新自定义版本
     * @param string $style null|'CSS'|'JS'
     */
    protected function refreshVersion($style = null) {
        $versionValue = maybe_unserialize(get_option('fct_custom_version'));
        // 新版本号
        $versionValue = ['v' => FENG_CUSTOM_VERSION];
        if ($style == null || $style == 'CSS') {
            $versionValue['css_version'] = $this->custom_css_new_version;
        }
        if ($style == null || $style == 'JS') {
            $versionValue['js_version'] = $this->custom_js_new_version;
        }
        // 更新配置
        update_option('fct_custom_version', maybe_serialize($versionValue));
    }
    
    /**
     * 构建css内容
     * @param string $style CSS内容或CSS文件
     * @param string $type 类型（string：样式字符串，filename：plus/admin/css目录下的文件名称）
     */
    private function appendStyle($style, $type = 'string') {
        if ($type == 'filename') {
            $line = $this->readCssFile($style);
            if ($line === false) {
                return false;
            }
            $this->style_line .= $line;
        }elseif($type == 'string') {
            $this->style_line .= $style;
        }
    }
    
    /**
     * 读取css文件
     * @param string $filename
     * @return string
     */
    private function readCssFile($filename) {
        $filename = plugin_dir_path(__DIR__) . 'includes/custom-css/' . $filename;
        return $this->readFile($filename);
    }
    
    /**
     * 构建并生成CSS文件
     * @return boolean
     */
    private function customCssFile() {
        $this->custom_css_new_version = time();
        // 可写方式打开文件
        $custom_css_new_filename =  $this->static_path . '/css/custom_' . $this->custom_css_new_version . '.css';
        $cssFile = fopen($custom_css_new_filename, 'w');
        if ($cssFile === false) {
            $this->error = esc_html__('文件打开失败！', 'feng-custom');
            return false;
        }
        
        // css 内容
        $style = '@charset "UTF-8";';
        $style .= $this->style_line;
        
        // 写入文件
        fwrite($cssFile, $style);
        
        // 关闭文件
        fclose($cssFile);
        
        // 删除上一个自定义css文件
        $old_css_file = $this->static_path . '/css/custom_' . $this->custom_css_version . '.css';
        wp_delete_file($old_css_file);
        
        return true;
    }
    
    /**
     * 构建js内容
     * @param string $script js内容或文件名称
     * @param string $type string: 字符串类型，filename：文件名称
     */
    private function appendScript($script, $type = 'string') {
        if ($type == 'string') {
            $this->script_line .= $script;
        }elseif ($type == 'filename') {
            $line = $this->readJsFile($script);
            if ($line === false) {
                return false;
            }
            $this->script_line .= $line;
        }
    }
    
    /**
     * 读取js文件
     * @param string $filename
     * @return boolean|string
     */
    private function readJsFile($filename) {
        $filename = FENG_CUSTOM_PATH . 'includes/custom-js/' . $filename;
        return $this->readFile($filename);
    }
    
    /**
     * 构建并生成js文件
     */
    private function customJsFile() {
        $this->custom_js_new_version = time();
        // 可写方式打开文件
        $custom_js_new_filename =  $this->static_path . '/js/custom_' . $this->custom_js_new_version . '.js';
        $jsFile = fopen($custom_js_new_filename, 'w');
        if ($jsFile === false) {
            $this->error = esc_html__('文件打开失败！', 'feng-custom');
            return false;
        }
        
        // js公用方法
        $script = $this->readJsFile('common.min.js');
        
        // js 内容
        $script .= 'jQuery(document).ready(function($) { ';
        $script .= $this->script_line;
        $script .= ' });';
        
        // 写入文件
        fwrite($jsFile, $script);
        
        // 关闭文件
        fclose($jsFile);
        
        // 删除上一个自定义css文件
        $old_js_file = $this->static_path . '/js/custom_' . $this->custom_js_version . '.js';
        wp_delete_file($old_js_file);
        
        return true;
    }
    
    /**
     * 初始化自定义文件目录
     * @return boolean
     */
    private function initPath() {
        // 获取缓存目录
        $css_path = $this->static_path . '/css';
        $js_path = $this->static_path . '/js';
        
        if (!is_dir($css_path)) {
            // 递归创建目录
            if (wp_mkdir_p($css_path) != true) {
                $this->error = __('自定义css目录创建失败', 'feng-custom');
                return false;
            }
        }
        
        if (!is_dir($js_path)) {
            // 递归创建目录
            if (wp_mkdir_p($js_path) != true) {
                $this->error = __('自定义js目录创建失败', 'feng-custom');
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * 读取文件内容为字符串
     * @param string $filename 文件路径
     * @return boolean|string
     */
    private function readFile($filename) {
        if (file_exists($filename) === false) {
            $this->error = esc_html__('文件打开失败！', 'feng-custom');
            return false;
        }
        $file = fopen($filename, "r");
        if ($file === false) {
            $this->error = esc_html__('文件打开失败！', 'feng-custom');
            return false;
        }
        $filestring = fread($file, filesize($filename));
        fclose($file);
        return $filestring;
    }
    
    /**
     * 获取错误信息
     * 
     * @return string|[]
     */
    public function getError() {
        return $this->error;
    }
}