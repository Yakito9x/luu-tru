<?php
// +----------------------------------------------------------------------
// | 晨风自定义 [ 用最简单的代码，实现最简单的事情。 ]
// +----------------------------------------------------------------------
// | Home Page: https://feng.pub/feng-custom
// +----------------------------------------------------------------------
// | Gitee: https://gitee.com/ouros/feng-custom
// +----------------------------------------------------------------------
// | WordPress: https://cn.wordpress.org/plugins/feng-custom
// +----------------------------------------------------------------------
// | Author: 阿锋 <mypen@163.com>
// +----------------------------------------------------------------------
/**
 * 表单类
 * 
 * @author 阿锋
 *
 */
class Feng_Custom_Forms {
    
    /**
     * 获取表单元素实体内容
     * 
     * @param string $type
     * @param [] $param
     */
    public function fetch($type, $param) {
        
    }
    
    /**
     * 输出开启选项
     * 
     * @param string $id 表单元素ID
     * @param string $lable 显示标签
     * @param string|int $value 元素值 
     */
    public function fetchOpen($id, $lable, $value) {
        ?>
        <fieldset>
        	<legend class="screen-reader-text">
        		<span><?php echo $lable; ?></span>
			</legend>
			<label for="fct_shurukuang"> 
				<input name="<?php echo $id; ?>" type="checkbox" id="<?php echo $id; ?>" value="1"
				    <?php checked( '1', $value ); ?> />
				<?php echo $lable; ?>
			</label>
		</fieldset>
		<?php 
    }
    
}