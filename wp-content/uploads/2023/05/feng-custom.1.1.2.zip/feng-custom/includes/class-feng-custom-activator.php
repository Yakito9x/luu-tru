<?php
// +----------------------------------------------------------------------
// | 晨风自定义 [ 用最简单的代码，实现最简单的事情。 ]
// +----------------------------------------------------------------------
// | Home Page: https://feng.pub/feng-custom
// +----------------------------------------------------------------------
// | Gitee: https://gitee.com/ouros/feng-custom
// +----------------------------------------------------------------------
// | WordPress: https://cn.wordpress.org/plugins/feng-custom
// +----------------------------------------------------------------------
// | Author: 阿锋 <mypen@163.com>
// +----------------------------------------------------------------------
/**
 * Fired during plugin activation
 *
 * @link       http://feng.pub
 *
 * @package    Feng_Custom
 * @subpackage Feng_Custom/includes
 * @author     阿锋 <mypen@163.com>
 */
class Feng_Custom_Activator {
    
	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 */
	public static function activate() {
	    // 刷新自定义文件
	    $custom_version = get_option('fct_custom_version');
	    if ($custom_version) {
	        $custom_version = explode('_', $custom_version);
	        if ($custom_version[0] != FENG_CUSTOM_VERSION) {
	            // 插件版本有更新，重新生成自定义文件
	            require_once FENG_CUSTOM_PATH . 'includes/class-feng-custom-build.php';
	            // 有自定义文件版本，重新生成自定义文件
	            $BuildClass = new Feng_Custom_Build();
	            $BuildClass->refreshAll();
	            require_once FENG_CUSTOM_PATH . 'includes/class-feng-custom-cache.php';
	            $CacheClass = new Feng_Custom_Cache();
	            $CacheClass->set('custom_version', [
	                'old' => $custom_version[0],
	                'current' => FENG_CUSTOM_VERSION,
	            ], null, 0);
	        }
	    }
	}
	

}
