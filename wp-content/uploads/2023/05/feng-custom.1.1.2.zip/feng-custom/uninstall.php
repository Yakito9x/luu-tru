<?php
// +----------------------------------------------------------------------
// | 晨风自定义 [ 用最简单的代码，实现最简单的事情。 ]
// +----------------------------------------------------------------------
// | Home Page: https://feng.pub/feng-custom
// +----------------------------------------------------------------------
// | Gitee: https://gitee.com/ouros/feng-custom
// +----------------------------------------------------------------------
// | WordPress: https://cn.wordpress.org/plugins/feng-custom
// +----------------------------------------------------------------------
// | Author: 阿锋 <mypen@163.com>
// +----------------------------------------------------------------------
/**
 * Fired when the plugin is uninstalled.
 *
 * @link       https://feng.pub
 *
 * @package    Feng_Custom
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
/**
 * 卸载删除插件配置
 */
delete_option('fct_xianshi_tianshu');
delete_option('fct_kaitong_shijian');
delete_option('fct_kaitong_bangding');
delete_option('fct_kaitong_neirong');

delete_option('fct_shurukuang');

delete_option('fct_denglong');
delete_option('fct_denglong_zi_1');
delete_option('fct_denglong_zi_2');
delete_option('fct_denglong_kaishi');
delete_option('fct_denglong_jieshu');

delete_option('fct_huise');
delete_option('fct_huise_kaishi');
delete_option('fct_huise_jieshu');

delete_option('fct_dengxiang');
delete_option('fct_dengxiang_bangding');

delete_option('fct_lianjie');
delete_option('fct_lianjie_weiba');

delete_option('fct_xuehua');
delete_option('fct_xuehua_option');

delete_option('fct_links');
delete_option('fct_links_option');

include_once plugin_dir_path(__FILE__) . 'includes/class-feng-custom-links.php';
$LinksClass = Feng_Custom_Links::getInstance();
$LinksClass->linksRssCronUnset();

delete_option('fct_custom_version');




