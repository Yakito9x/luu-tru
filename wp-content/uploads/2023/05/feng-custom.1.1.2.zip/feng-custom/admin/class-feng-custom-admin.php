<?php
// +----------------------------------------------------------------------
// | 晨风自定义 [ 用最简单的代码，实现最简单的事情。 ]
// +----------------------------------------------------------------------
// | Home Page: https://feng.pub/feng-custom
// +----------------------------------------------------------------------
// | Gitee: https://gitee.com/ouros/feng-custom
// +----------------------------------------------------------------------
// | WordPress: https://cn.wordpress.org/plugins/feng-custom
// +----------------------------------------------------------------------
// | Author: 阿锋 <mypen@163.com>
// +----------------------------------------------------------------------
/**
 * 管理类
 *
 * @link       http://feng.pub
 *
 * @package    Feng_Custom
 * @subpackage Feng_Custom/admin
 * @author     阿锋 <mypen@163.com>
 */
class Feng_Custom_Admin {

	/**
	 * The ID of this plugin.
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	
	/**
	 * Initialize the class and set its properties.
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {
	    $this->plugin_name = $plugin_name;
	    $this->version = $version;
	    
	    // 添加后台管理菜单
	    add_action( 'admin_menu', array( $this, 'admin_menu' ) );
	}

	/**
	 * Register the stylesheets for the admin area.
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Feng_Custom_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Feng_Custom_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

	}

	/**
	 * Register the JavaScript for the admin area.
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Plugin_Name_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Feng_Custom_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

	}
	
	/**
	 * 初始化后台菜单
	 */
	public function admin_menu() {
	    // 晨风自定义
	    add_submenu_page('themes.php', __('晨风自定义', 'feng-custom'), __('晨风自定义', 'feng-custom'), 'edit_theme_options','feng-custom' , array(__CLASS__,'admin_page'));
	    
	    // 链接错误信息
	    if (get_option('fct_links') == 1) {
	        add_submenu_page('link-manager.php', __('日志信息', 'feng-custom'), __('日志信息', 'feng-custom'), 'manage_links', 'feng-custom', array(__CLASS__,'links_log'));
	    }
	}
	
	/**
	 * 显示管理页面
	 */
	public static function admin_page() {
	    // 操作
	    $action = in_array(sanitize_key(isset($_GET['action']) ? $_GET['action'] : ''), [
	        // 定义可用页面
	        'option',      // 配置
	        'info',        // 鸣谢
	        'links',       // 链接
	        'snowflake',   // 雪花飘落
	        'mailstyle',   // 邮件样式
	    ]) ? sanitize_key($_GET['action']) : 'option';
	    
	    require_once FENG_CUSTOM_PATH . 'admin/partials/' . $action . '.php';
	}
	
	/**
	 * 显示错误信息
	 */
	public static function links_log() {
	    require_once FENG_CUSTOM_PATH . 'admin/partials/links-log.php';
	}
	
}
