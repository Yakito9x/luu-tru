<?php
// +----------------------------------------------------------------------
// | 晨风自定义 [ 用最简单的代码，实现最简单的事情。 ]
// +----------------------------------------------------------------------
// | Home Page: https://feng.pub/feng-custom
// +----------------------------------------------------------------------
// | Gitee: https://gitee.com/ouros/feng-custom
// +----------------------------------------------------------------------
// | WordPress: https://cn.wordpress.org/plugins/feng-custom
// +----------------------------------------------------------------------
// | Author: 阿锋 <mypen@163.com>
// +----------------------------------------------------------------------
/**
 * links-error.php
 */
/** WordPress Administration Bootstrap */
require_once ABSPATH . 'wp-admin/admin.php';

// 管理权限
if (! current_user_can('edit_theme_options')){
    wp_die(esc_html__( '对不起，您无权访问该页。' ));
}
?> 

<h1><?php esc_html_e('RSS聚合，获取RSS源的记录信息', 'feng-custom'); ?></h1>

<?php 
include_once FENG_CUSTOM_PATH . 'includes/class-feng-custom-cache.php';
$CacheClass = new Feng_Custom_Cache();
$logs = $CacheClass->get('links_rss_simplepie_log', 'links-log');
if ($logs) {
    $date_format = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );
    foreach ($logs as $data) {
        ?>
        	<h2><?php echo esc_html__('记录时间：', 'feng-custom') . wp_date($date_format, $data['log_time']);?></h2>
        	<?php 
        	$feed_ruls = $data['feed_urls'];
        	foreach ($feed_ruls as $key => $value) {
        	    if (isset($data['error'][$key])) {
        	        ?>
            	        <div class="notice notice-error">
                	        <p><a target="_blank" href="<?php echo $value; ?>"><b><?php echo $value; ?></b></a></p>
                	        <p><?php echo $data['error'][$key]; ?></p>
            	        </div>
            	        <?php 
            	    }else {
            	        ?>
            	        <div class="notice notice-success">
                	        <p><a target="_blank" href="<?php echo $value; ?>"><b><?php echo $value; ?></b></a> <span>OK</span></p>
            	        </div>
            	        <?php 
            	    }
            	}
        	?>
        	<hr />
        <?php 
    }
}