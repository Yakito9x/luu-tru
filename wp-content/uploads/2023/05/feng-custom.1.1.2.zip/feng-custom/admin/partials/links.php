<?php
// +----------------------------------------------------------------------
// | 晨风自定义 [ 用最简单的代码，实现最简单的事情。 ]
// +----------------------------------------------------------------------
// | Home Page: https://feng.pub/feng-custom
// +----------------------------------------------------------------------
// | Gitee: https://gitee.com/ouros/feng-custom
// +----------------------------------------------------------------------
// | WordPress: https://cn.wordpress.org/plugins/feng-custom
// +----------------------------------------------------------------------
// | Author: 阿锋 <mypen@163.com>
// +----------------------------------------------------------------------
/**
 * 链接·RSS配置页面
 */
require_once FENG_CUSTOM_PATH . 'admin/partials/header.php';
require_once FENG_CUSTOM_PATH . 'includes/class-feng-custom-links.php';
$LinksClass = Feng_Custom_Links::getInstance();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 处理数据
    $result = $LinksClass->doPost();
    if ($result === false) {
        // 失败
        $state = false;
        $message = $LinksClass->getError();
    } else {
        // 成功
        $state = true;
        $message = esc_html__('更新完成，请刷新页面。', 'feng-custom');
    }
    $links_open = $_POST['fct_links'];
    $links_option = $_POST;
    require_once FENG_CUSTOM_PATH . 'admin/partials/message.php';
}else {
    $links_open = get_option( 'fct_links' );
    $links_option = $LinksClass->getOption(true);
}
$admin_links_url = admin_url('link-manager.php');
$admin_category_url = admin_url('edit-tags.php?taxonomy=link_category');
$admin_page_url = admin_url('edit.php?post_type=page');
?>
<form action="" method="post">
	<table class="form-table" role="presentation">
		<tbody>
			<tr>
				<th scope="row">
					<?php esc_html_e( '开启链接', 'feng-custom' ); ?>
					<a href="https://gitee.com/ouros/feng-custom/wikis/%E4%BD%BF%E7%94%A8%E5%B8%AE%E5%8A%A9/%E9%93%BE%E6%8E%A5%E5%8A%9F%E8%83%BD"
    					title="<?php esc_html_e('点击获取帮助', 'feng-custom'); ?>"
    					target="_blank">?</a>
				</th>
				<td>
					<fieldset>
						<legend class="screen-reader-text">
							<span><?php esc_html_e( '开启链接功能', 'feng-custom' ); ?></span>
						</legend>
						<label for="fct_links"> <input name="fct_links" type="checkbox"
							id="fct_links" value="1"
							<?php checked( '1', $links_open ); ?> />
	<?php esc_html_e( '开启链接功能', 'feng-custom' ); ?></label>
					</fieldset>
					<p class="description"><?php esc_html_e( '开启后通过「后台 -> 链接」管理链接及分类', 'feng-custom' ); ?></p>
					<?php 
					if ($links_open == 1) {
					    ?>
					    <p class="description">
					    	<a href="<?php echo $admin_links_url; ?>"><?php esc_html_e('管理链接', 'feng-custom');?></a>
					    </p>
					    <?php
					}
					?>
				</td>
			</tr>
			<tr>
				<td class="td-hr" colspan="2"><hr /></td>
			</tr>
<?php
$has_pages = (bool) get_posts(
    array(
        'post_type'      => 'page',
        'posts_per_page' => 1,
        'post_status'    => array(
            'publish',
            'draft',
        ),
    )
);
?>
			<tr>
				<th scope="row"><?php esc_html_e('链接页面', 'feng-custom');?></th>
				<td>
					<fieldset>
						<p>
							<label class="label-title" for="links_page_id"><?php esc_html_e('选择友情链接页面', 'feng-custom');?></label>
						</p>
    					<?php 
    					if ( $has_pages ) {
    					    wp_dropdown_pages(
    					        array(
    					            'name'              => 'links_page_id',
    					            'show_option_none'  => esc_html__( '&mdash; 选择友情链接页面 &mdash;' ),
    					            'option_none_value' => '0',
    					            'selected'          => $links_option['links_page_id'],
    					            'post_status'       => array( 'draft', 'publish' ),
    					        )
    					    );
    					}
    					?>
					</fieldset>
					<?php 
					if ($links_open == 1) {
					    ?> 
    					<p class="description">
    						<a href="<?php echo $admin_page_url; ?>"><?php esc_html_e('管理页面', 'feng-custom');?></a>
    					</p>
					    <?php
					}
					?>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td>
					<fieldset>
						<label class="label-title" for="links_category"><?php esc_html_e('选择链接页面显示的分类', 'feng-custom');?></label>
					</fieldset>
					<fieldset>
						<?php $LinksClass->selectCatsDisplay('links_category', $links_option['links_category']); ?>
					</fieldset>
					<?php 
					if ($links_open == 1) {
					    ?>  
    					<p class="description">
    						<a href="<?php echo $admin_category_url; ?>"><?php esc_html_e('管理分类', 'feng-custom');?></a>
    					</p>
					    <?php
					}
					?>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td>
					<fieldset>
						<p><label class="label-title" for="links_page_cats_order"><?php esc_html_e('选择分类的排序方式', 'feng-custom');?></label></p>
    					<select name="links_page_cats_order" id="links_page_cats_order">
                        	<option value="0">— <?php esc_html_e('', 'feng-custom');?>选择分类排序方式 —</option>
                        	<option class="level-0" value="name-asc" <?php selected( 'name-asc', $links_option['links_page_cats_order'] ); ?>><?php esc_html_e('按名称升序↑', 'feng-custom');?></option>
                        	<option class="level-0" value="name-desc" <?php selected( 'name-desc', $links_option['links_page_cats_order'] ); ?>><?php esc_html_e('按名称降序↓', 'feng-custom');?></option>
                        	<option class="level-0" value="id-asc" <?php selected( 'id-asc', $links_option['links_page_cats_order'] ); ?>><?php esc_html_e('按ID升序↑', 'feng-custom');?></option>
                        	<option class="level-0" value="id-desc" <?php selected( 'id-desc', $links_option['links_page_cats_order'] ); ?>><?php esc_html_e('按ID降序↓', 'feng-custom');?></option>
                        </select>
					</fieldset>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td>
					<fieldset>
						<p><label class="label-title" for="links_page_card_order"><?php esc_html_e('选择链接卡片的排序方式', 'feng-custom');?></label></p>
    					<select name="links_page_card_order" id="links_page_card_order">
                        	<option value="0">— <?php esc_html_e('选择链接排序方式', 'feng-custom');?> —</option>
                        	<option class="level-0" value="rand" <?php selected( 'rand', $links_option['links_page_card_order'] ); ?>><?php esc_html_e('随机排序', 'feng-custom');?></option>
                        	<option class="level-0" value="name-asc" <?php selected( 'name-asc', $links_option['links_page_card_order'] ); ?>><?php esc_html_e('按名称升序↑', 'feng-custom');?></option>
                        	<option class="level-0" value="name-desc" <?php selected( 'name-desc', $links_option['links_page_card_order'] ); ?>><?php esc_html_e('按名称降序↓', 'feng-custom');?></option>
                        	<option class="level-0" value="id-asc" <?php selected( 'id-asc', $links_option['links_page_card_order'] ); ?>><?php esc_html_e('按ID升序↑', 'feng-custom');?></option>
                        	<option class="level-0" value="id-desc" <?php selected( 'id-desc', $links_option['links_page_card_order'] ); ?>><?php esc_html_e('按ID降序↓', 'feng-custom');?></option>
                        	<option class="level-0" value="rating-asc" <?php selected( 'rating-asc', $links_option['links_page_card_order'] ); ?>><?php esc_html_e('按评级升序↑', 'feng-custom');?></option>
                        </select>
					</fieldset>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td>
					<fieldset>
						<p><?php esc_html_e('选择链接卡片样式', 'feng-custom'); ?></p>
					</fieldset>
					<div>
						<label style="display: inline-block; vertical-align: top; text-align: center;">
							<input type="radio" name="links_page_card" value="1" <?php checked( '1', $links_option['links_page_card'] ); ?>>
							<br />
							<img src="<?php echo FENG_CUSTOM_URL . 'admin/img/links-page-card-1.png?v=' . FENG_CUSTOM_VERSION;?>" />
						</label>
						<label style="display: inline-block;  vertical-align: top; text-align: center; margin-left: 30px;">
							<input type="radio" name="links_page_card" value="2" <?php checked( '2', $links_option['links_page_card'] ); ?>> 
							<br />
							<img src="<?php echo FENG_CUSTOM_URL . 'admin/img/links-page-card-2.png?v=' . FENG_CUSTOM_VERSION; ?>" />
						</label>
					</div>
				</td>
			</tr>
			<tr>
				<td class="td-hr" colspan="2"><hr /></td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e('RSS聚合页面', 'feng-custom')?></th>
				<td>
					<fieldset>
						<p>
							<label for="links_rss_page_id"><?php esc_html_e('选择RSS聚合页面', 'feng-custom');?></label>
						</p>
    					<?php
    					wp_dropdown_pages(
    						array(
    							'name'              => 'links_rss_page_id',
    							'show_option_none'  => esc_html__( '&mdash; 选择RSS聚合页面 &mdash;' ),
    							'option_none_value' => '0',
    							'selected'          => $links_option['links_rss_page_id'],
    							'post_status'       => array( 'draft', 'publish' ),
    						)
    					);
    					?>
					</fieldset>
					<?php 
					if ($links_open == 1) {
					    ?> 
    					<p class="description">
    						<a href="<?php echo $admin_page_url; ?>"><?php esc_html_e('管理页面', 'feng-custom');?></a>
    					</p>
					    <?php
					}
					?>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td>
					<fieldset>
						<p><?php esc_html_e('RSS聚合显示的链接分类', 'feng-custom');?></p>
					</fieldset>
					<fieldset>
						<?php $LinksClass->selectCatsDisplay('links_rss_category', $links_option['links_rss_category']); ?>
					</fieldset>
					<?php 
					if ($links_open == 1) {
					    ?> 
					    <p class="description">
    						<a href="<?php echo $admin_category_url; ?>"><?php esc_html_e('管理分类', 'feng-custom');?></a>
    					</p>
					    <?php
					}
					?>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td>
					<fieldset>
						<label for="links_rss_page_limit"><?php esc_html_e('显示聚合数量', 'feng-custom');?></label>
						<input name="links_rss_page_limit" type="number" id="links_rss_page_limit"
        					value="<?php echo esc_attr($links_option['links_rss_page_limit']); ?>"
        					placeholder="50" class="small-text"> <?php esc_html_e('默认：', 'feng-custom'); ?>50
					</fieldset>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td>
					<fieldset>
						<label for="links_rss_page_expire"><?php esc_html_e('列表缓存过期时间', 'feng-custom');?></label>
						<input name="links_rss_page_expire" type="number" id="links_rss_page_expire"
        					value="<?php echo esc_attr($links_option['links_rss_page_expire']); ?>"
        					placeholder="3600" class="small-text"> <?php esc_html_e('秒，（默认：3600秒，0表示不启用）', 'feng-custom'); ?>
					</fieldset>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td>
					<fieldset>
						<label for="links_page_rss_cron"> <input name="links_page_rss_cron" type="checkbox"
							id="links_page_rss_cron" value="1"
							<?php checked( '1', $links_option['links_page_rss_cron'] ); ?> />
						<?php _e( '开启定时RSS缓存计划，每小时执行一次', 'feng-custom' ); ?></label>
					</fieldset>
					<p class=""><?php _e('开启前请确保WP-Cron可用，推荐使用系统任务执行WP-Cron以免拖累页面加载速度。', 'feng-custom');?></p>
				</td>
			</tr>
			<tr>
				<td class="td-hr" colspan="2"><hr /></td>
			</tr>
			<tr>
				<th scope="row">
					<?php esc_html_e('自定义样式（继承）', 'feng-custom'); ?>
					<a href="https://gitee.com/ouros/feng-custom/wikis/%E4%BD%BF%E7%94%A8%E5%B8%AE%E5%8A%A9/%E9%93%BE%E6%8E%A5%E5%8A%9F%E8%83%BD"
    					title="<?php esc_html_e('点击获取帮助', 'feng-custom'); ?>"
    					target="_blank">?</a>
				</th>
				<td>
					<fieldset>
						<label class="label-title" for="links_page_style"><?php esc_html_e('自定义CSS样式（可以为空）', 'feng-custom');?></label>
					</fieldset>
					<p>
						<textarea name="links_page_style" rows="5" cols="50"
							id="links_page_style" class="large-text code"><?php echo esc_html( stripslashes($links_option['links_page_style']) ); ?></textarea>
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td>
					<fieldset>
						<label class="label-title" for="links_page_class"><?php esc_html_e('添加CSS class（可以为空）', 'feng-custom');?></label>
						<input name="links_page_class" type="text"
        					id="links_page_class"
        					value="<?php echo esc_attr($links_option['links_page_class']); ?>"
        					placeholder="<?php esc_html_e('例：', 'feng-custom' ); ?>alignfull ct-container"
        					class="regular-text">
					</fieldset>
				</td>
			</tr>
			<tr>
				<td class="td-hr" colspan="2"><hr /></td>
			</tr>
			<tr>
				<th scope="row">
					<?php esc_html_e( '显示支持信息', 'feng-custom' ); ?>
				</th>
				<td>
					<fieldset>
						<label for="links_page_prowered"> <input name="links_page_prowered" type="checkbox"
							id="links_page_prowered" value="1"
							<?php checked( '1', $links_option['links_page_prowered'] ); ?> />
						<?php _e( '链接及RSS聚合页面内显示：', 'feng-custom' ); ?>Links & RSS Prowered by <a target="_blank" href="https://feng.pub/feng-custom">Feng Custom</a></label>
					</fieldset>
				</td>
			</tr>
		</tbody>
	</table>
	<input name="action_nonce" type="hidden"
		value="<?php echo esc_attr(wp_create_nonce('fct-admin-option-links')); ?>">
	<?php submit_button(); ?>
</form>

<?php 
require_once FENG_CUSTOM_PATH . 'admin/partials/footer.php';
?>