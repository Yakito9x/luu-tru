<?php
// +----------------------------------------------------------------------
// | 晨风自定义 [ 用最简单的代码，实现最简单的事情。 ]
// +----------------------------------------------------------------------
// | Home Page: https://feng.pub/feng-custom
// +----------------------------------------------------------------------
// | Gitee: https://gitee.com/ouros/feng-custom
// +----------------------------------------------------------------------
// | WordPress: https://cn.wordpress.org/plugins/feng-custom
// +----------------------------------------------------------------------
// | Author: 阿锋 <mypen@163.com>
// +----------------------------------------------------------------------
/**
 * 鸣谢页面
 */
require_once FENG_CUSTOM_PATH . 'admin/partials/header.php';
?>
<h1 style="padding-top: 30px"><?php esc_html_e('说明', 'feng-custom'); ?></h1>
<div style="padding-left: 30px">
	<p><?php esc_html_e('该插件主要使用前端代码实现，定时执行通过浏览器端完成，可节省服务器资源，请放心使用。', 'feng-custom'); ?></p>
</div>
<h2><?php esc_html_e('主要组件', 'feng-custom'); ?></h2>
<div style="padding-left: 30px">
	<h3><?php esc_html_e('Fancybox（图片灯箱）', 'feng-custom'); ?></h3>
	<p>
		<a href="https://fancyapps.com/docs/ui/quick-start" target="_blank">https://fancyapps.com/docs/ui/quick-start</a>
	</p>
	<h3><?php esc_html_e('activate-power-mode（输入框七彩光子特效）', 'feng-custom'); ?></h3>
	<p>
		<a href="https://github.com/disjukr/activate-power-mode"
			target="_blank">https://github.com/disjukr/activate-power-mode</a>
	</p>
	<h3><?php esc_html_e('JQuery Snowfall（雪花飘落）', 'feng-custom'); ?></h3>
	<p>
		<a href="https://github.com/loktar00/JQuery-Snowfall" target="_blank">https://github.com/loktar00/JQuery-Snowfall</a>
	</p>
	<h3><?php esc_html_e('CSS3动画灯笼', 'feng-custom'); ?></h3>
	<p>
		<a href="https://zmingcx.com/hanging-lantern.html" target="_blank">https://zmingcx.com/hanging-lantern.html</a>
	</p>
</div>
<h2><?php esc_html_e('主要贡献', 'feng-custom'); ?></h2>
<div style="padding-left: 30px">
	<p>
		<a href="https://feng.pub?utm_source=feng-custom" target="_blank">阿锋</a>
	</p>
</div>
<?php
require_once FENG_CUSTOM_PATH . 'admin/partials/footer.php';
?>