<?php
// +----------------------------------------------------------------------
// | 晨风自定义 [ 用最简单的代码，实现最简单的事情。 ]
// +----------------------------------------------------------------------
// | Home Page: https://feng.pub/feng-custom
// +----------------------------------------------------------------------
// | Gitee: https://gitee.com/ouros/feng-custom
// +----------------------------------------------------------------------
// | WordPress: https://cn.wordpress.org/plugins/feng-custom
// +----------------------------------------------------------------------
// | Author: 阿锋 <mypen@163.com>
// +----------------------------------------------------------------------
/**
 * 配置页面
 */
require_once FENG_CUSTOM_PATH . 'admin/partials/header.php';
require_once FENG_CUSTOM_PATH . 'includes/class-feng-custom-option.php';
$OptionClass = new Feng_Custom_Option();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 处理数据
    $result = $OptionClass->doPost();
    if ($result === false) {
        // 失败
        $state = false;
        $message = $OptionClass->getError();
    } else {
        // 成功
        $state = true;
        $message = esc_html__('更新完成', 'feng-custom');
    }
    $option = $_POST;
    require_once FENG_CUSTOM_PATH . 'admin/partials/message.php';
}else {
    $option = $OptionClass->getOption(true);
    $option['fct_kaitong_shijian'] = $option['fct_kaitong_shijian'] ? fct_get_date($option['fct_kaitong_shijian']) : '';
    $option['fct_denglong_kaishi'] = $option['fct_denglong_kaishi'] ? fct_get_date($option['fct_denglong_kaishi']) : '';
    $option['fct_denglong_jieshu'] = $option['fct_denglong_jieshu'] ? fct_get_date($option['fct_denglong_jieshu']) : '';
    $option['fct_huise_kaishi'] = $option['fct_huise_kaishi'] ? fct_get_date($option['fct_huise_kaishi']) : '';
    $option['fct_huise_jieshu'] = $option['fct_huise_jieshu'] ? fct_get_date($option['fct_huise_jieshu']) : '';
}
?>
<form action="" method="post">
	<table class="form-table" role="presentation">
		<tbody>
			<tr>
				<th scope="row"><?php esc_html_e( '显示运行天数', 'feng-custom' ); ?></th>
				<td>
					<fieldset>
						<legend class="screen-reader-text">
							<span><?php esc_html_e( '在底部显示运行天数', 'feng-custom' ); ?></span>
						</legend>
						<label for="fct_xianshi_tianshu"> <input
							name="fct_xianshi_tianshu" type="checkbox"
							id="fct_xianshi_tianshu" value="1"
							<?php checked( '1', $option['fct_xianshi_tianshu'] ); ?> />
	<?php esc_html_e( '在底部显示运行天数', 'feng-custom' ); ?></label>
					</fieldset>
					<p class="description"><?php esc_html_e( '需要设置', 'feng-custom' ); ?><b><?php esc_html_e( '博客开通时间', 'feng-custom' ); ?></b>
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td><label class="label-title" for="fct_kaitong_shijian"><?php esc_html_e('博客开通时间', 'feng-custom')?></label>
					<input name="fct_kaitong_shijian" type="text"
					id="fct_kaitong_shijian"
					value="<?php echo esc_attr($option['fct_kaitong_shijian']); ?>"
					placeholder="<?php esc_html_e('例：', 'feng-custom' ); ?>2021-05-01 15:20:00"
					class="regular-text"></td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td><label class="label-title" for="fct_kaitong_bangding"><?php esc_html_e('绑定页面元素', 'feng-custom'); ?></label>
					<input name="fct_kaitong_bangding" type="text"
					id="fct_kaitong_bangding"
					value="<?php echo esc_attr($option['fct_kaitong_bangding']); ?>"
					placeholder="<?php esc_html_e('例：', 'feng-custom' ); ?>footer"
					class="regular-text">
					<p class="description"><?php esc_html_e('该绑定元素使用jQuery 选择器，例如：.copyright 或 body', 'feng-custom'); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td>
					<fieldset>
						<p>
							<label for="fct_kaitong_neirong"><?php esc_html_e('显示内容', 'feng-custom')?></label>
						</p>
						<p>
							<textarea name="fct_kaitong_neirong" rows="3" cols="50"
								id="fct_kaitong_neirong" class="large-text code"><?php echo esc_html( stripslashes($option[ 'fct_kaitong_neirong' ]) ); ?></textarea>
						</p>
						<p class="description"><?php esc_html_e('系统会将 {days} 替换为天数', 'feng-custom')?>
						
						
						
						<p class="description"><?php esc_html_e('例：&lt;p&gt;站点已运行 {days} 天，感谢有你！&lt;p&gt;', 'feng-custom')?></p>
					</fieldset>
				</td>
			</tr>
			<tr>
				<td class="td-hr" colspan="2"><hr /></td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( '七彩光子特效', 'feng-custom' ); ?></th>
				<td>
					<fieldset>
						<legend class="screen-reader-text">
							<span><?php esc_html_e( '开启输入框七彩光子特效', 'feng-custom' ); ?></span>
						</legend>
						<label for="fct_shurukuang"> <input name="fct_shurukuang"
							type="checkbox" id="fct_shurukuang" value="1"
							<?php checked( '1', $option[ 'fct_shurukuang' ] ); ?> />
	<?php esc_html_e( '开启输入框七彩光子特效', 'feng-custom' ); ?></label>
					</fieldset>
				</td>
			</tr>
			<tr>
				<td class="td-hr" colspan="2"><hr /></td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( '欢庆佳节', 'feng-custom' ); ?></th>
				<td>
					<fieldset>
						<legend class="screen-reader-text">
							<span><?php esc_html_e( '点亮灯笼', 'feng-custom' ); ?></span>
						</legend>
						<label for="fct_denglong"> <input name="fct_denglong"
							type="checkbox" id="fct_denglong" value="1"
							<?php checked( '1', $option[ 'fct_denglong' ] ); ?> />
	<?php esc_html_e( '点亮灯笼', 'feng-custom' ); ?></label>
					</fieldset>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td><label class="label-title" for="fct_denglong_zi_1"><?php esc_html_e( '文字', 'feng-custom' ); ?></label>
					<label for="fct_denglong_zi_1"><?php esc_html_e( '前一个灯笼', 'feng-custom' ); ?></label>
					<input name="fct_denglong_zi_1" type="text" id="fct_denglong_zi_1"
					placeholder="<?php esc_html_e( '例：春节', 'feng-custom' ); ?>"
					value="<?php echo esc_attr( $option['fct_denglong_zi_1'] ); ?>"
					class="small-text"> <label for="fct_denglong_zi_2"><?php esc_html_e( '后一个灯笼', 'feng-custom' ); ?></label>
					<input name="fct_denglong_zi_2" type="text" id="fct_denglong_zi_2"
					placeholder="<?php esc_html_e( '例：快乐', 'feng-custom' ); ?>"
					value="<?php echo esc_attr( $option['fct_denglong_zi_2'] ); ?>"
					class="small-text">
					<p class="description"><?php esc_html_e( '灯笼文字，点亮并在有效期内生效', 'feng-custom' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td><label class="label-title" for="fct_denglong_kaishi"><?php esc_html_e( '开始时间（可以为空）', 'feng-custom' ); ?></label>
					<input name="fct_denglong_kaishi" type="text"
					id="fct_denglong_kaishi"
					value="<?php echo $option['fct_denglong_kaishi']; ?>"
					placeholder="<?php esc_html_e( '例：', 'feng-custom' ); ?>2022-10-01 00:00:00"
					class="regular-text">
					<p class="description"><?php esc_html_e( '到时间灯笼自动点亮，需点亮灯笼', 'feng-custom' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td><label class="label-title" for="fct_denglong_jieshu"><?php esc_html_e( '结束时间（可以为空）', 'feng-custom' ); ?></label>
					<input name="fct_denglong_jieshu" type="text"
					id="fct_denglong_jieshu"
					value="<?php echo $option['fct_denglong_jieshu']; ?>"
					placeholder="<?php esc_html_e( '例：', 'feng-custom' ); ?>2022-10-08 00:00:00"
					class="regular-text">
					<p class="description"><?php esc_html_e( '到时间灯笼自动熄灭，需点亮灯笼', 'feng-custom' ); ?></p>
				</td>
			</tr>
			<tr>
				<td class="td-hr" colspan="2"><hr /></td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( '博客灰色', 'feng-custom' ); ?></th>
				<td>
					<fieldset>
						<legend class="screen-reader-text">
							<span><?php esc_html_e( '将博客设置为灰色模式', 'feng-custom' ); ?></span>
						</legend>
						<label for="fct_huise"> <input name="fct_huise" type="checkbox"
							id="fct_huise" value="1"
							<?php checked( '1', $option[ 'fct_huise' ] ); ?> />
	<?php esc_html_e( '将博客设置为灰色模式', 'feng-custom' ); ?></label>
					</fieldset>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td><label class="label-title" for="fct_huise_kaishi"><?php esc_html_e( '开始时间（可以为空）', 'feng-custom' ); ?></label>
					<input name="fct_huise_kaishi" type="text" id="fct_huise_kaishi"
					value="<?php echo esc_attr($option['fct_huise_kaishi']); ?>"
					placeholder="<?php esc_html_e( '例：', 'feng-custom' ); ?>2008-05-12 00:00:00"
					class="regular-text">
					<p class="description"><?php esc_html_e( '到时自动变灰，需设置为灰色模式', 'feng-custom' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td><label class="label-title" for="fct_huise_jieshu"><?php esc_html_e( '结束时间（可以为空）', 'feng-custom' ); ?></label>
					<input name="fct_huise_jieshu" type="text" id="fct_huise_jieshu"
					value="<?php echo esc_attr($option['fct_huise_jieshu']); ?>"
					placeholder="<?php esc_html_e( '例：', 'feng-custom' ); ?>2008-05-13 00:00:00"
					class="regular-text">
					<p class="description"><?php esc_html_e( '到时间自动恢复，需设置为灰色模式', 'feng-custom' ); ?></p>
				</td>
			</tr>
			<tr>
				<td class="td-hr" colspan="2"><hr /></td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( '图片灯箱', 'feng-custom' ); ?></th>
				<td>
					<fieldset>
						<legend class="screen-reader-text">
							<span><?php esc_html_e( '开启图片灯箱', 'feng-custom' ); ?></span>
						</legend>
						<label for="fct_dengxiang"> <input name="fct_dengxiang"
							type="checkbox" id="fct_dengxiang" value="1"
							<?php checked( '1', $option[ 'fct_dengxiang' ] ); ?> />
	<?php esc_html_e( '开启图片灯箱', 'feng-custom' ); ?></label>
					</fieldset>
					<p class="description"><?php esc_html_e( '图片灯箱，采用Fancybox', 'feng-custom' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td><label class="label-title" for="fct_dengxiang_bangding"><?php esc_html_e( '绑定图片元素', 'feng-custom' ); ?></label>
					<input name="fct_dengxiang_bangding" type="text"
					id="fct_dengxiang_bangding"
					value="<?php echo esc_attr($option['fct_dengxiang_bangding']); ?>"
					placeholder="<?php esc_html_e( '例：', 'feng-custom' ); ?>.wp-block-image img"
					class="regular-text">
					<p class="description"><?php esc_html_e( '例：', 'feng-custom' ); ?>.wp-block-image img</p>
				</td>
			</tr>
			<tr>
				<td class="td-hr" colspan="2"><hr /></td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( '链接小尾巴', 'feng-custom' ); ?></th>
				<td>
					<fieldset>
						<legend class="screen-reader-text">
							<span><?php esc_html_e( '开启第三方链接小尾巴', 'feng-custom' ); ?></span>
						</legend>
						<label for="fct_lianjie"> <input name="fct_lianjie"
							type="checkbox" id="fct_lianjie" value="1"
							<?php checked( '1', $option[ 'fct_lianjie' ] ); ?> />
	<?php esc_html_e( '开启第三方链接小尾巴', 'feng-custom' ); ?></label>
					</fieldset>
					<p class="description"><?php esc_html_e( '打开第三方链接时自动添加来源', 'feng-custom' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td><label class="label-title" for="fct_lianjie_weiba"><?php esc_html_e( '小尾巴', 'feng-custom' ); ?></label>
					<input name="fct_lianjie_weiba" type="text" id="fct_lianjie_weiba"
					value="<?php echo esc_attr($option['fct_lianjie_weiba']); ?>"
					placeholder="<?php esc_html_e( '例：', 'feng-custom' ); ?>utm_source=feng.pub"
					class="regular-text">
					<p class="description">https://ha.cn?utm_source=feng.pub</p></td>
			</tr>
		</tbody>
	</table>
	<input name="action_nonce" type="hidden"
		value="<?php echo esc_attr(wp_create_nonce('fct-admin-option')); ?>">
	<?php submit_button(); ?>
</form>

<?php 
require_once FENG_CUSTOM_PATH . 'admin/partials/footer.php';
?>