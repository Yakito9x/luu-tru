<?php
// +----------------------------------------------------------------------
// | 晨风自定义 [ 用最简单的代码，实现最简单的事情。 ]
// +----------------------------------------------------------------------
// | Home Page: https://feng.pub/feng-custom
// +----------------------------------------------------------------------
// | Gitee: https://gitee.com/ouros/feng-custom
// +----------------------------------------------------------------------
// | WordPress: https://cn.wordpress.org/plugins/feng-custom
// +----------------------------------------------------------------------
// | Author: 阿锋 <mypen@163.com>
// +----------------------------------------------------------------------
/**
 * 雪花配置页面
 */
require_once FENG_CUSTOM_PATH . 'admin/partials/header.php';
require_once FENG_CUSTOM_PATH . 'includes/class-feng-custom-option.php';
$OptionClass = new Feng_Custom_Option();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 处理数据
    $result = $OptionClass->doPostSnowflake();
    if ($result === false) {
        // 失败
        $state = false;
        $message = $OptionClass->getError();
    } else {
        // 成功
        $state = true;
        $message = esc_html__('更新完成', 'feng-custom');
    }
    $xuehua_open = $_POST['fct_xuehua'];
    $xuehua_option = $_POST['fct_xuehua_option'];
    require_once FENG_CUSTOM_PATH . 'admin/partials/message.php';
}else {
    $xuehua_open = get_option( 'fct_xuehua' );
    // 雪花特效配置
    $xuehua_option = $OptionClass->getOptionSnowflake();
}
?>
<form action="" method="post">
	<table class="form-table" role="presentation">
		<tbody>
			<tr>
				<th scope="row"><?php esc_html_e( '雪花特效', 'feng-custom' ); ?> <a
					href="https://gitee.com/ouros/feng-custom/wikis/%E4%BD%BF%E7%94%A8%E5%B8%AE%E5%8A%A9/%E9%9B%AA%E8%8A%B1%E7%89%B9%E6%95%88"
					title="<?php esc_html_e('点击获取帮助', 'feng-custom'); ?>"
					target="_blank">?</a></th>
				<td>
					<fieldset>
						<legend class="screen-reader-text">
							<span><?php esc_html_e( '开启雪花飘落特效', 'feng-custom' ); ?></span>
						</legend>
						<label for="fct_xuehua"> <input name="fct_xuehua" type="checkbox"
							id="fct_xuehua" value="1"
							<?php checked( '1', $xuehua_open ); ?> />
	<?php esc_html_e( '开启雪花飘落特效', 'feng-custom' ); ?></label>
					</fieldset>
					<p class="description"><?php esc_html_e( '开启后全站将显示雪花飘落特效', 'feng-custom' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td>
					<fieldset>
						<p>
							<label for="fct_xuehua_option_image"><?php esc_html_e('飘落图片', 'feng-custom')?></label>
						</p>
						<p>
							<textarea name="fct_xuehua_option[image]" rows="3" cols="50"
								id="fct_xuehua_option_image" class="large-text code"><?php echo esc_html( stripslashes($xuehua_option['image']) ); ?></textarea>
						</p>
						<p class="description"><?php esc_html_e('输入飘落图片的链接，也可使用网络图片或插件内置图片。', 'feng-custom')?><a
								href="https://gitee.com/ouros/feng-custom/wikis/%E4%BD%BF%E7%94%A8%E5%B8%AE%E5%8A%A9/%E9%9B%AA%E8%8A%B1%E7%89%B9%E6%95%88"
								target="_blank"><?php esc_html_e('查看使用帮助', 'feng-custom'); ?></a>
						
						
						<p class="description"><?php esc_html_e('多个图片请换一行，每行只能又一个图片（半角逗号禁用）', 'feng-custom')?></p>
					</fieldset>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td><label class="label-title" for="fct_xuehua_option_text"><?php esc_html_e( '雪花字符', 'feng-custom' ); ?></label>
					<input name="fct_xuehua_option[text]" type="text"
					id="fct_xuehua_option_text"
					value="<?php echo esc_attr($xuehua_option['text']); ?>"
					placeholder="" class="regular-text">
					<p class="description"><?php esc_html_e('推荐使用：✻，多个字符请用半角逗号隔开：❄,❉,❅,❆,✻,✼,❈,❊,✥,✺,坏蛋,哈哈,〇,😁,❄️,🧨', 'feng-custom'); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td><label class="label-title" for="fct_xuehua_option_color"><?php esc_html_e( '雪花颜色', 'feng-custom' ); ?></label>
					<input name="fct_xuehua_option[color]" type="text"
					id="fct_xuehua_option_color"
					value="<?php echo esc_attr($xuehua_option['color']); ?>"
					placeholder="<?php esc_html_e('默认：', 'feng-custom'); ?>#FFFFFF"
					class="regular-text">
					<p class="description"><?php esc_html_e('推荐使用：#FFFFFF，多种颜色请用半角逗号隔开：#FFFFFF,#FFFB00,#73FCD6', 'feng-custom'); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td><label class="label-title" for="fct_xuehua_option_min_size"><?php esc_html_e( '雪花大小', 'feng-custom' ); ?></label>
					<input name="fct_xuehua_option[minSize]" type="number"
					id="fct_xuehua_option_min_size"
					value="<?php echo esc_attr($xuehua_option['minSize']); ?>"
					placeholder="<?php esc_html_e('默认：', 'feng-custom'); ?>1"
					class="small-text"> px &nbsp;&nbsp; ～ &nbsp;&nbsp; <input
					name="fct_xuehua_option[maxSize]" type="number"
					id="fct_xuehua_option_max_size"
					value="<?php echo esc_attr($xuehua_option['maxSize']); ?>"
					placeholder="<?php esc_html_e('默认：', 'feng-custom'); ?>14"
					class="small-text"> px <?php esc_html_e('（雪花大小将在范围内随机生成）', 'feng-custom'); ?>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td><label class="label-title" for="fct_xuehua_option_min_speed"><?php esc_html_e( '飘落速度', 'feng-custom' ); ?></label>
					<input name="fct_xuehua_option[minSpeed]" type="number"
					id="fct_xuehua_option_min_speed"
					value="<?php echo esc_attr($xuehua_option['minSpeed']); ?>"
					placeholder="<?php esc_html_e('默认：', 'feng-custom'); ?>1"
					class="small-text"> &nbsp;&nbsp; ~ &nbsp;&nbsp; <input
					name="fct_xuehua_option[maxSpeed]" type="number"
					id="fct_xuehua_option_max_speed"
					value="<?php echo esc_attr($xuehua_option['maxSpeed']); ?>"
					placeholder="<?php esc_html_e('默认：', 'feng-custom'); ?>5"
					class="small-text"> <?php esc_html_e('数字越大速度越快，最大速度不建议大于10', 'feng-custom'); ?>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td><label class="label-title" for="fct_xuehua_option_count"><?php esc_html_e( '雪花数量', 'feng-custom' ); ?></label>
					<input name="fct_xuehua_option[count]" type="number"
					id="fct_xuehua_option_count"
					value="<?php echo esc_attr($xuehua_option['count']); ?>"
					placeholder="<?php esc_html_e('默认：', 'feng-custom'); ?>30"
					class="small-text"><?php esc_html_e(' 个 （飘落雪花的总数)', 'feng-custom'); ?>
				</td>
			</tr>
			<tr>
				<th scope="row"></th>
				<td><label class="label-title" for="fct_xuehua_option_zindex"><?php esc_html_e( '图层等级', 'feng-custom' ); ?></label>
					<input name="fct_xuehua_option[zIndex]" type="number"
					id="fct_xuehua_option_zindex"
					value="<?php echo esc_attr($xuehua_option['zIndex']); ?>"
					placeholder="<?php esc_html_e('默认：', 'feng-custom'); ?>100"
					class="regular-text">
					<p class="description"><?php esc_html_e('如果雪花被覆盖，请设置为更大的数字', 'feng-custom'); ?></p>
				</td>
			</tr>

		</tbody>
	</table>
	<input name="action_nonce" type="hidden"
		value="<?php echo esc_attr(wp_create_nonce('fct-admin-option-snowflake')); ?>">
	<?php submit_button(); ?>
</form>

<?php 
require_once FENG_CUSTOM_PATH . 'admin/partials/footer.php';
?>