<?php
// +----------------------------------------------------------------------
// | 晨风自定义 [ 用最简单的代码，实现最简单的事情。 ]
// +----------------------------------------------------------------------
// | Home Page: https://feng.pub/feng-custom
// +----------------------------------------------------------------------
// | Gitee: https://gitee.com/ouros/feng-custom
// +----------------------------------------------------------------------
// | WordPress: https://cn.wordpress.org/plugins/feng-custom
// +----------------------------------------------------------------------
// | Author: 阿锋 <mypen@163.com>
// +----------------------------------------------------------------------
/**
 * header.php（被引用）
 */

/** WordPress Administration Bootstrap */
require_once ABSPATH . 'wp-admin/admin.php';

// 管理权限
if (! current_user_can('edit_theme_options')){
    wp_die(esc_html__( '对不起，您无权访问该页。' ));
}

$feng_custom_url = admin_url('themes.php?page=feng-custom');

// 显示页面
$option_screen = ! isset($_GET['action']) ? true : false;
$info_screen = (isset($_GET['action']) && 'info' === $_GET['action']) ? true : false;
$snowflake_screen = (isset($_GET['action']) && 'snowflake' === $_GET['action']) ? true : false;
$links_screen = (isset($_GET['action']) && 'links' === $_GET['action']) ? true : false;

$nav_tab_active_class = ' nav-tab-active';
$nav_aria_current     = ' aria-current="page"';

require_once ABSPATH . 'wp-admin/admin-header.php';
?>
<style>
input.small-text, input[type=number].small-text {
    width: 90px;
}
</style>
<div class="wrap">
	<h1 class="wp-heading-inline"><?php esc_html_e('晨风自定义', 'feng-custom'); ?></h1>
	
	<hr class="wp-header-end">
	
	<nav class="nav-tab-wrapper wp-clearfix" aria-label="">
		<a href="<?php echo esc_url( $feng_custom_url ); ?>"
			class="nav-tab<?php echo esc_attr( $option_screen ? $nav_tab_active_class : '' ); ?>"
			<?php echo esc_attr( $option_screen ? $nav_aria_current : '' ); ?>><?php esc_html_e('效果配置', 'feng-custom'); ?></a>
			
		<a href="<?php echo esc_url(add_query_arg(array('action'=>'snowflake')), $feng_custom_url ); ?>"
			class="nav-tab<?php echo esc_attr( $snowflake_screen ? $nav_tab_active_class : '' ); ?>"
			<?php echo esc_attr( $snowflake_screen ? $nav_aria_current : '' ); ?>><?php esc_html_e('雪花飘落', 'feng-custom'); ?></a>
			
		<a href="<?php echo esc_url(add_query_arg(array('action'=>'links')), $feng_custom_url ); ?>"
			class="nav-tab<?php echo esc_attr( $links_screen ? $nav_tab_active_class : '' ); ?>"
			<?php echo esc_attr( $links_screen ? $nav_aria_current : '' ); ?>><?php esc_html_e('链接·RSS', 'feng-custom'); ?></a>
			
		<a href="<?php echo esc_url(add_query_arg(array('action'=>'info')), $feng_custom_url ); ?>"
			class="nav-tab<?php echo esc_attr( $info_screen ? $nav_tab_active_class : '' ); ?>"
			<?php echo esc_attr( $info_screen ? $nav_aria_current : '' ); ?>><?php esc_html_e('鸣谢', 'feng-custom'); ?></a>
	</nav>
	
</div>

