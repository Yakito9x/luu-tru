<?php
// +----------------------------------------------------------------------
// | 晨风自定义 [ 用最简单的代码，实现最简单的事情。 ]
// +----------------------------------------------------------------------
// | Home Page: https://feng.pub/feng-custom
// +----------------------------------------------------------------------
// | Gitee: https://gitee.com/ouros/feng-custom
// +----------------------------------------------------------------------
// | WordPress: https://cn.wordpress.org/plugins/feng-custom
// +----------------------------------------------------------------------
// | Author: 阿锋 <mypen@163.com>
// +----------------------------------------------------------------------
/**
 * 提示消息（被引用）
 */
?>
<div id="setting-error-settings_updated"
	class="notice notice-<?php echo esc_attr( $state ? 'success' : 'error'); ?> settings-error is-dismissible">
	<p>
		<strong><?php echo esc_html( $message ); ?></strong>
	</p>
	<button type="button" class="notice-dismiss" onclick="fct_notice_dismiss()">
		<span class="screen-reader-text"><?php esc_html_e('忽略此通知。', 'feng-custom'); ?></span>
	</button>
</div>

<script>
function fct_notice_dismiss() {
	document.getElementById("setting-error-settings_updated").style.display="none";
}
</script>
