# 晨风自定义 for WordPress

#### 介绍

晨风自定义是WordPress 插件，主要用于站点网页显示，如雪花飘落、底部运行天数、网页灰色、节日气氛灯笼、输入框七彩光子特效等等。

WordPress 发布页：[https://cn.wordpress.org/plugins/feng-custom](https://cn.wordpress.org/plugins/feng-custom)

#### 主要功能

- 显示运行天数
- 输入框七彩光子特效
- 欢庆佳节灯笼
- 站点设置为灰色
- 图片灯箱
- 第三方链接添加小尾巴
- 网页雪花特效（万能飘落，支持字图片、字符串）
- 链接功能（友情链接）
- 链接RSS聚合功能

#### 下载安装

**推荐使用WordPress 仪表盘安装使用**

1. 进入WordPress仪表盘，点击“插件->安装插件”；
2. 搜索“ 晨风自定义 ”，点击安装；
3. 安装完毕后，启用“Feng Custom”插件；
4. 通过“主题”->“晨风自定义” 进入插件设置界面进行相关设置.
5. 最后保存设置即可。

**插件下载**
1. Gitee 克隆/下载 zip
[https://gitee.com/ouros/feng-custom](https://gitee.com/ouros/feng-custom)

2. 发行版页面下载
[https://gitee.com/ouros/feng-custom/releases](https://gitee.com/ouros/feng-custom/releases)

**FTP上传安装**

1. 解压插件压缩包，将解压获得文件夹上传至wordpress安装目录下的 “/wp-content/plugins/”目录.
2. 访问WordPress仪表盘，进入“插件”->“已安装插件”，在插件列表中找到“晨风自定义”，点击“启用”.
3. 通过“主题”->“晨风自定义” 进入插件设置界面进行相关设置.
4. 最后保存设置即可。

**仪表盘上传安装**

1. 进入WordPress仪表盘，点击“插件-安装插件”；
2. 点击界面左上方的“上传按钮”，选择本地提前下载好的插件压缩包，点击“现在安装”；
3. 安装完毕后，启用“晨风自定义 Feng Custom”插件；
4. 通过“主题”->“晨风自定义” 进入插件设置界面进行相关设置.
5. 最后保存设置即可。

#### 使用帮助

配置管理页面路径：管理后台->主题->晨风自定义

您可以在这里设置各项参数，如博客站点开通时间、灯笼开始及结束时间、第三方链接小尾巴等。

**后台配置页面截图**

![晨风自定义配置内容截图](https://images.gitee.com/uploads/images/2022/0404/201334_0a98dd54_75683.jpeg)

#### 主要组件

- Fancybox [https://fancyapps.com/docs/ui/quick-start](https://fancyapps.com/docs/ui/quick-start)
- 输入框七彩光子特效 [https://github.com/disjukr/activate-power-mode](https://github.com/disjukr/activate-power-mode)
- JQuery Snowfall（雪花飘落） [https://github.com/loktar00/JQuery-Snowfall](https://github.com/loktar00/JQuery-Snowfall)
- CSS3灯笼动画 [https://zmingcx.com/hanging-lantern.html](https://zmingcx.com/hanging-lantern.html)

#### 更新列表

1.1.2（2023.02.01）
- 修复 刷新自定义文件版本号未记录问题
- 修复 删除缓存文件因未判断文件是否存在而报错的问题

1.1.1（2023.01.31）
- 更新 将系统生成的自定义CSS、JS文件移动至wp-content/cache/feng-custom目录下
- 更新 解决更改配置后需要清除浏览器加载缓，使用时间戳作为自定义CSS及JS文件名

1.1.0 (2022.05.13)
- 新增 链接（友情链接）功能
- 新增 链接RSS聚合功能

1.0.6 (2022.04.20)
- 更新 雪花飘落更换为JQuery-Snowfall，优化为万能飘落，支持图片及文字。
- 更新 雪花飘落使用压缩后的文件。
- 修复 雪花创建时飘落速度错误的问题。
- 更新 雪花飘落自适应浏览器窗口宽度，当宽度小于900时飘落数量将减少一半。

1.0.5 (2022.04.17)
- 修复 时间格式验证，返回错误问题

1.0.4 (2022.04.17)
- 更新 Validate 验证类新增验证方法
- 更新 自定义js使用压缩后的文件min.js
- 新增 common.js公共方法
- 新增 雪花飘落特效

1.0.3 (2022.04.13)
- 后台更新后，自动刷新custom.js、custom.css 文件
- 修复 链接小尾巴固定不可变的错误

1.0.2 (2022.04.10)
- 修复 增强安全输入POST数据
- 修复 统一版本号

1.0.1 (2022.04.08)
- 修复 第三方链接小尾巴，链接按钮点击错误问题
- 更新 页面使用WP安全输出
- 新增 卸载插件后删除插件相关配置项
- 新增 后台禁用插件后，将各功能关闭，仅关闭不清数据

1.0.0 (2021.04.04)
- 新增 显示运行天数
- 新增 输入框七彩光子特效
- 新增 欢庆佳节灯笼
- 新增 站点设置为灰色
- 新增 图片灯箱
- 新增 第三方链接添加小尾巴
